@echo off
call "%~dp0SETUP-WINDOWS.bat" %*
exit /b %ERRORLEVEL%
