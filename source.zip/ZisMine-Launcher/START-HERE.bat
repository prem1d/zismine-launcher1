@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
title ZisMine Launcher - Start Here
color 0B
:menu
cls
echo.
echo ================================================================
echo                    ZISMINE LAUNCHER
echo ================================================================
echo.
echo  This menu is for the developer who builds the launcher.
echo  Players only need the final EXE installer.
echo.
echo  [1] Install build tools (Node.js, Rust, Visual Studio C++)
echo  [2] Build Windows EXE installer (NSIS)
echo  [3] Build both EXE and MSI installers
echo  [4] Check installed build tools
echo  [5] Exit
echo.
choice /C 12345 /N /M "Choose an option [1-5]: "
if errorlevel 5 goto :end
if errorlevel 4 goto :check
if errorlevel 3 goto :both
if errorlevel 2 goto :build
if errorlevel 1 goto :setup
:setup
call "%~dp0SETUP-WINDOWS.bat"
goto :after
:build
call "%~dp0BUILD-WINDOWS.bat"
goto :after
:both
call "%~dp0BUILD-WINDOWS.bat" all
goto :after
:check
call "%~dp0CHECK-WINDOWS.bat"
:after
echo.
pause
goto :menu
:end
exit /b 0
