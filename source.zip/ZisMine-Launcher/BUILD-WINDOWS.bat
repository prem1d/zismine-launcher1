@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
title ZisMine Launcher - Build Windows
color 0B

set "ROOT=%~dp0"
set "PROJECT=%ROOT%source"
cd /d "%ROOT%"

echo.
echo ================================================================
echo                 ZISMINE LAUNCHER - BUILD
echo ================================================================
echo.

if not exist "%PROJECT%\package.json" goto :missing_project

if exist "%ProgramFiles%\nodejs" set "PATH=%ProgramFiles%\nodejs;%PATH%"
if exist "%USERPROFILE%\.cargo\bin" set "PATH=%USERPROFILE%\.cargo\bin;%PATH%"

where node >nul 2>&1
if errorlevel 1 goto :node_missing
where npm >nul 2>&1
if errorlevel 1 goto :npm_missing
where cargo >nul 2>&1
if errorlevel 1 goto :cargo_missing

set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
set "VS_PATH="
if not exist "%VSWHERE%" goto :cpp_missing
for /f "usebackq delims=" %%I in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VS_PATH=%%I"
if not defined VS_PATH goto :cpp_missing
if not exist "%VS_PATH%\Common7\Tools\VsDevCmd.bat" goto :vsdevcmd_missing

call "%VS_PATH%\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64
if errorlevel 1 goto :vsdevcmd_failed
where cl >nul 2>&1
if errorlevel 1 goto :cl_missing

set "BUNDLE_ARGS=nsis"
if /I "%~1"=="msi" set "BUNDLE_ARGS=msi"
if /I "%~1"=="all" set "BUNDLE_ARGS=nsis,msi"
if not "%~1"=="" if /I not "%~1"=="msi" if /I not "%~1"=="all" goto :bad_argument

pushd "%PROJECT%"
if not exist "node_modules" (
  echo [INFO] node_modules not found. Installing npm dependencies...
  call npm install --no-audit --no-fund
  if errorlevel 1 goto :build_failed
)

echo.
echo Building the application and installer(s): %BUNDLE_ARGS%
echo This is a release build. The first Rust build can take several minutes.
echo.
call npm run tauri -- build --bundles %BUNDLE_ARGS%
if errorlevel 1 goto :build_failed

popd

echo.
echo ================================================================
echo                    BUILD COMPLETED
echo ================================================================
echo.
if /I "%BUNDLE_ARGS%"=="nsis" (
  echo NSIS EXE installer:
  echo %PROJECT%\src-tauri\target\release\bundle\nsis\
  dir /b "%PROJECT%\src-tauri\target\release\bundle\nsis\*.exe" 2>nul
) else if /I "%BUNDLE_ARGS%"=="msi" (
  echo MSI installer:
  echo %PROJECT%\src-tauri\target\release\bundle\msi\
  dir /b "%PROJECT%\src-tauri\target\release\bundle\msi\*.msi" 2>nul
) else (
  echo EXE installer:
  dir /b "%PROJECT%\src-tauri\target\release\bundle\nsis\*.exe" 2>nul
  echo MSI installer:
  dir /b "%PROJECT%\src-tauri\target\release\bundle\msi\*.msi" 2>nul
)
echo.
echo This window will remain open. Press any key to close.
pause >nul
exit /b 0

:build_failed
set "RC=%ERRORLEVEL%"
popd
echo.
echo [ERROR] Build failed. Exit code: %RC%
goto :failed

:missing_project
echo [ERROR] source\package.json was not found. Extract the full archive first.
goto :failed
:node_missing
echo [ERROR] Node.js is missing. Run SETUP-WINDOWS.bat first.
goto :failed
:npm_missing
echo [ERROR] npm is missing. Reinstall Node.js or run SETUP-WINDOWS.bat.
goto :failed
:cargo_missing
echo [ERROR] Cargo is missing. Run SETUP-WINDOWS.bat, then reopen the terminal.
goto :failed
:cpp_missing
echo [ERROR] Visual Studio C++ Build Tools were not detected.
echo Run SETUP-WINDOWS.bat and make sure Desktop development with C++ is installed.
goto :failed
:vsdevcmd_missing
echo [ERROR] VsDevCmd.bat was not found in the Visual Studio installation.
goto :failed
:vsdevcmd_failed
echo [ERROR] Could not initialize the Visual Studio C++ build environment.
goto :failed
:cl_missing
echo [ERROR] MSVC compiler cl.exe is not available after VsDevCmd.
goto :failed
:bad_argument
echo Usage: BUILD-WINDOWS.bat [nsis^|msi^|all]
echo Default: NSIS EXE installer.
goto :failed

:failed
echo.
echo ================================================================
echo                      BUILD FAILED
echo ================================================================
echo.
echo Read the error above. This window is intentionally kept open.
echo For help, send a screenshot of this window.
echo.
pause
exit /b 1
