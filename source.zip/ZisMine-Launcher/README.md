# ZisMine Launcher 0.2.0 — Fabric Edition

Рабочий исходный проект лаунчера Minecraft Java Edition на **Tauri 2 + Rust + React + TypeScript + Vite**. Единственный поддерживаемый профиль — **Minecraft 1.20.1 + Fabric Loader + Fabric API**.

> **Статус:** исходники переработаны, frontend/Rust статически проверены скриптами проекта. В текущей среде нет Rust/Cargo и полноценного Windows runner, поэтому сборка EXE, реальные сетевые загрузки Mojang/Fabric, Microsoft-вход и запуск клиента до меню здесь не подтверждены. Готового EXE в этом архиве нет: его нужно собрать на Windows.

## Что входит

- Красно-графитовая тема ZisMine с исходным фирменным знаком Z; новые SVG/PNG/ICO ассеты и иконка приложения.
- Кастомная рамка окна Tauri: собственный заголовок, перетаскивание, изменение размера по краям и углам, свернуть/развернуть/закрыть.
- Четыре раздела: Главная, Аккаунт, Моды, Настройки; крупная типографика, адаптивные состояния и плавные переходы с поддержкой `prefers-reduced-motion`.
- Жёсткая фиксация Minecraft `1.20.1` и Fabric Loader; vanilla/Fabric profile merged with official Fabric Meta API.
- Автоматическая загрузка совместимого Fabric API из Fabric Maven в `<папка Minecraft>/instances/1.20.1/mods`, проверка SHA-1 и удаление старого Fabric API после успешной загрузки новой версии.
- Java 17 из официального Mojang Runtime Manifest; Windows Runtime размещается в `runtime/` рядом с установленным EXE. NSIS — current-user install.
- Microsoft Device Code → Xbox Live → XSTS → Minecraft Services → entitlement/profile checks; refresh token хранится в системном keyring. Требуется настроенный публичный OAuth Client ID.
- На странице модов есть кнопка открытия фактической папки `instances/1.20.1/mods` в Проводнике.
- Управление локальными профилями и фактически установленными `.jar` Fabric-модами: список, включение/отключение, удаление; Fabric API защищён от случайного удаления.
- Для модов показывается совместимость с Minecraft 1.20.1 по common `depends.minecraft` SemVer-подобным требованиям; непонятные форматы помечаются «Версия не указана», а не объявляются совместимыми.
- Release-сборка Windows использует GUI subsystem; запускаемый Java-процесс открывается через `javaw.exe`/`CREATE_NO_WINDOW`. stdout/stderr игры сохраняются в `logs/latest.log`; внутренняя консоль лаунчера скрыта.
- Загрузчик проверяет SHA-1/размеры, использует временные `.part` файлы, ограничивает URL allowlist, поддерживает отмену и прогресс.

## Поддерживаемая платформа

Основная целевая сборка — Windows 10/11 x64. Код остаётся на Tauri, но автоматическая установка Java рядом с приложением и тестируемая сборка в этой итерации ориентированы прежде всего на Windows x64. игроки скачивают готовый установщик; Node.js/Rust/Visual Studio нужны только разработчику.

## Разработка и сборка Windows

Нужны Node.js LTS, Rust stable MSVC и Visual Studio 2022 Build Tools с workload **Desktop development with C++**. Из корня проекта: сначала `SETUP-WINDOWS.bat` (или короткий ярлык `StepWindows.bat`), после успешной установки инструментов — `BUILD-WINDOWS.bat`.

Или вручную из `source`:

```powershell
npm install
npm run build
npm run tauri -- build --bundles nsis
```

Готовый установщик после успешной сборки появится в:

```text
source\src-tauri\target\release\bundle\nsis\ZisMine Launcher_0.2.0_x64-setup.exe
```

Standalone GUI executable: `source\src-tauri\target\release\zismine-launcher.exe`.

## Microsoft OAuth

Для реального Microsoft-входа нужен публичный Application (client) ID приложения Microsoft с включённым Device Code Flow. Укажи его в дополнительных настройках лаунчера. Client ID не является секретом; пароль от Microsoft-аккаунта лаунчер не запрашивает. Профиль Microsoft проверяется по Xbox/XSTS и праву владения Minecraft Java Edition. Локальный профиль не является лицензией и не будет выдаваться за неё.

## Файлы и Runtime

- Windows app data и настройки находятся в системной папке приложения.
- Игровые данные по умолчанию — `%APPDATA%\.minecraft`.
- Java Runtime — `runtime\` рядом с EXE в каталоге установки. Для NSIS выбран current-user режим, чтобы эта папка была доступна для записи без постоянного UAC.
- Логи Minecraft — `%APPDATA%\.minecraft\instances\1.20.1\logs\latest.log` (при изменённой папке игры — внутри выбранного каталога).
- Пользовательские миры не удаляются при переустановке игрового клиента.

## Тесты

```powershell
python tests\audit_minecraft.py
python tests\validate_windows_scripts.py
cd source\src-tauri
cargo test
```

Первые две команды — статические regression checks. `cargo test` требует Rust toolchain. Реальный smoke test должен подтвердить первую установку, Fabric Loader/API, Java 17, Microsoft OAuth с лицензией, старт Minecraft до главного меню, закрытие/повторный запуск и отсутствие лишнего окна консоли. Не считай эти этапы пройденными только по результату компиляции.
