@echo off
setlocal
chcp 65001 >nul
call "%~dp0SETUP-WINDOWS.bat" %*
exit /b %ERRORLEVEL%
