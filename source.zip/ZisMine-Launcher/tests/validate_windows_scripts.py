"""Static regression checks for the Windows helper scripts.

These checks validate script structure and required safeguards. They do not
replace executing the BAT files on a real Windows 10/11 machine.
"""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
setup = (ROOT / "SETUP-WINDOWS.bat").read_text(encoding="utf-8")
build = (ROOT / "BUILD-WINDOWS.bat").read_text(encoding="utf-8")
step = (ROOT / "StepWindows.bat").read_text(encoding="utf-8")
check = (ROOT / "CHECK-WINDOWS.bat").read_text(encoding="utf-8")
readme = (ROOT / "README.md").read_text(encoding="utf-8")

checks = []
def test(name: str, condition: bool) -> None:
    checks.append((name, bool(condition)))

# Installer entry point and project layout.
test("setup BAT exists", (ROOT / "SETUP-WINDOWS.bat").is_file())
test("project package.json exists", (ROOT / "source" / "package.json").is_file())
test("setup validates project path", '"%PROJECT%\\package.json"' in setup)
test("setup handles unsupported architecture", ":unsupported_architecture" in setup)
test("setup checks WinGet", "where winget" in setup)
test("setup has final pause", "pause\nexit /b 0" in setup)
test("setup has failure pause", "pause\nexit /b 1" in setup)
test("setup records log file", 'SETUP-WINDOWS.log' in setup)
test("setup has no fragile self-elevation", "Start-Process" not in setup and "-Verb RunAs" not in setup)
test("setup does not silently close after success", "SETUP COMPLETED SUCCESSFULLY" in setup and "pause" in setup)

# Dependencies and verification.
test("Node.js LTS package ID present", "OpenJS.NodeJS.LTS" in setup)
test("Rustup package ID present", "Rustlang.Rustup" in setup)
test("Visual Studio Build Tools package ID present", "Microsoft.VisualStudio.2022.BuildTools" in setup)
test("C++ workload requested", "Microsoft.VisualStudio.Workload.VCTools" in setup)
test("recommended Windows SDK components requested", "--includeRecommended" in setup)
test("existing VS modify waits via cmd, not unsupported setup.exe --wait", 'start "" /wait "%VS_SETUP%" modify' in setup and '--norestart --wait\nset "RC=%ERRORLEVEL%"' not in setup)
test("stable MSVC toolchain installed", "stable-x86_64-pc-windows-msvc" in setup)
test("Node.js version is checked", "process.versions.node" in setup)
test("npm dependencies installed", "npm install --no-audit --no-fund" in setup)
test("failed npm install has an error route", ":npm_install_failed" in setup)

# Build entry point and aliases.
test("build script pauses on success and failure", build.count("pause") >= 2)
test("build initializes MSVC environment", "VsDevCmd.bat" in build)
test("build checks compiler availability", "where cl" in build)
test("build supports NSIS and MSI", "BUNDLE_ARGS=nsis,msi" in build and "BUNDLE_ARGS=msi" in build)
test("all bundle argument is comma-separated for Tauri CLI", "--bundles %BUNDLE_ARGS%" in build and "BUNDLE_ARGS=nsis,msi" in build)
test("start menu offers install, build, and diagnostics", all(x in (ROOT / "START-HERE.bat").read_text(encoding="utf-8") for x in ("SETUP-WINDOWS.bat", "BUILD-WINDOWS.bat", "CHECK-WINDOWS.bat")))
test("build invokes Tauri release build", "npm run tauri -- build --bundles" in build)
test("StepWindows alias calls setup", "SETUP-WINDOWS.bat" in step)
test("diagnostic script reports core tools", all(x in check for x in ("node --version", "npm --version", "rustc --version", "cargo --version", "winget --version")))
test("README explains setup and player requirements", "игроки скачивают готовый установщик" in readme and "StepWindows.bat" in readme)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(("PASS" if ok else "FAIL") + "  " + name)
print(f"\n{len(checks) - len(failed)}/{len(checks)} static checks passed")
if failed:
    print("Failed checks:", ", ".join(failed))
    sys.exit(1)
