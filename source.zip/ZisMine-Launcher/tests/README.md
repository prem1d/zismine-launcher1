# Test plan and execution record

This document separates tests present in source from tests that still require a native runner.

## Rust unit tests currently in source

Run from `source/src-tauri`:

```bash
cargo test
```

Current unit-test coverage includes:

- Offline UUID generation.
- Version Manifest JSON parsing.
- HTTPS Mojang host allowlist.
- SHA-1 calculation and download path traversal guard.
- Java major-version parsing and launch argument substitution.
- Runtime manifest major parsing, safe path validation and relative symlink resolution.

The source contains 11 `#[test]` / `#[tokio::test]` functions. They have **not** been executed in the current build environment because Rust/Cargo are not installed.

## Native integration / acceptance matrix (not yet executed)

| Area | Required test | Status |
|---|---|---|
| Mojang metadata | Fetch current manifest and a version JSON | Not run |
| Vanilla install | Install a current release from an empty game directory | Not run |
| Repair | Corrupt client JAR/library/asset and verify redownload | Not run |
| Runtime | Install Java 8/17/21/25 when selected version requires it | Not run |
| Launch | Start a release and snapshot, capture exit code and logs | Not run |
| Microsoft | Complete device-code login with a licensed Java account | Not run |
| Entitlement | Reject account without Java entitlement | Not run |
| Credentials | Verify Windows Credential Manager / macOS Keychain / Linux Secret Service | Not run |
| Settings | Restart app and verify persistence / RAM limits | Not run |
| Network | Interrupt download, cancel, resume and retry | Not run |
| Platform | Smoke test Windows 10/11, macOS Intel/ARM64 and Linux clean images | Not run |

Do not mark this matrix passed until the test has actually been performed and its environment recorded.
