import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url));

export default defineConfig({
  plugins: [react()],
  publicDir: path.resolve(here, '../assets'),
  base: './',
  clearScreen: false,
  server: { strictPort: true, port: 1420 },
  build: {
    outDir: path.resolve(here, '../build/frontend'),
    emptyOutDir: true,
    sourcemap: false,
    target: 'es2022',
    minify: 'esbuild',
  },
});
