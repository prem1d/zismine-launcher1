export type SkinModel = 'Classic' | 'Slim';

export type SkinData = {
  model: SkinModel;
  skinPath: string | null;
  capePath: string | null;
};

export type Profile = {
  id: string;
  name: string;
  kind: 'offline' | 'microsoft';
  uuid: string;
  xuid?: string | null;
  client_id?: string | null;
  skin_url?: string | null;
};

export type Settings = {
  minecraft_dir: string;
  selected_version: string;
  min_memory_mb: number;
  max_memory_mb: number;
  java_path: string;
  auto_java: boolean;
  width: number;
  height: number;
  fullscreen: boolean;
  language: string;
  show_console: boolean;
  check_updates: boolean;
  oauth_client_id: string;
};

export type ServerConfig = {
  name: string;
  address: string;
  port: number;
  recommended_version: string;
  description: string;
  website: string;
  telegram: string;
  discord: string;
  status_api: string;
  news_url: string;
};

export type ServerStatus = {
  online: boolean;
  players_online: number | null;
  players_max: number | null;
};

export type ManifestVersion = {
  id: string;
  type: string;
  url: string;
  releaseTime: string;
};

export type Bootstrap = {
  profiles: Profile[];
  active_profile_id: string | null;
  installed_versions: string[];
  settings: Settings;
  server: ServerConfig;
  total_memory_mb: number;
  available_memory_mb: number;
  java_runtime_dir: string;
  java_runtime_installed: boolean;
  server_status: ServerStatus | null;
};

export type DownloadProgress = {
  version: string;
  completed: number;
  total: number;
  current_file: string;
  phase: string;
  downloaded_bytes: number;
  total_bytes: number;
  speed_bytes_sec: number;
};

export type ModInfo = {
  file_name: string;
  name: string;
  version: string;
  description: string;
  compatibility: 'compatible' | 'incompatible' | 'unknown';
  enabled: boolean;
  essential: boolean;
};
