import type { Profile } from '../types';
import { ProfileAvatar } from './ProfileAvatar';
export function Topbar({ profile, title, onAccounts }: { profile?: Profile; title: string; onAccounts: () => void }) {
  return <header className="topbar">
    <div className="topbar-heading"><span className="topbar-mark" />{title}<span className="topbar-version">1.20.1 · Fabric</span></div>
    <button className="account-pill" onClick={onAccounts} title="Управление игровым профилем">
      <ProfileAvatar profile={profile} className={`avatar ${profile?.kind === 'microsoft' ? 'avatar-premium' : ''}`} />
      <span className="account-meta"><strong>{profile?.name ?? 'Подключить аккаунт'}</strong><small>{profile?.kind === 'offline' ? 'Локальный профиль' : profile?.kind === 'microsoft' ? 'Лицензионный аккаунт' : 'Профиль не выбран'}</small></span>
    </button>
  </header>;
}
