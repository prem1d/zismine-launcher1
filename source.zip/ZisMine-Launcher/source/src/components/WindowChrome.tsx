import { useEffect, useState } from 'react';
import type { MouseEvent } from 'react';

type ResizeDirection = 'East' | 'North' | 'NorthEast' | 'NorthWest' | 'South' | 'SouthEast' | 'SouthWest' | 'West';
import { Minus, Square, X } from 'lucide-react';
import { getCurrentWindow } from '@tauri-apps/api/window';

export function WindowChrome() {
  const [maximized, setMaximized] = useState(false);
  useEffect(() => {
    const windowHandle = getCurrentWindow();
    void windowHandle.isMaximized().then(setMaximized).catch(() => undefined);
    let unlisten: (() => void) | undefined;
    void windowHandle.onResized(() => { void windowHandle.isMaximized().then(setMaximized).catch(() => undefined); }).then(fn => { unlisten = fn; });
    return () => unlisten?.();
  }, []);
  const handle = getCurrentWindow();
  const resize = (direction: ResizeDirection) => (event: MouseEvent<HTMLDivElement>) => {
    event.preventDefault();
    void handle.startResizeDragging(direction).catch(() => undefined);
  };
  return <>
  <div className="window-resize-layer" aria-hidden="true">
    <div className="resize-edge resize-n" onMouseDown={resize('North')} />
    <div className="resize-edge resize-e" onMouseDown={resize('East')} />
    <div className="resize-edge resize-s" onMouseDown={resize('South')} />
    <div className="resize-edge resize-w" onMouseDown={resize('West')} />
    <div className="resize-corner resize-ne" onMouseDown={resize('NorthEast')} />
    <div className="resize-corner resize-nw" onMouseDown={resize('NorthWest')} />
    <div className="resize-corner resize-se" onMouseDown={resize('SouthEast')} />
    <div className="resize-corner resize-sw" onMouseDown={resize('SouthWest')} />
  </div>
  <header className="window-chrome" data-tauri-drag-region>
    <div className="window-brand" data-tauri-drag-region><img src="/brand/zismine-mark.svg" alt="" /><span>ZisMine Launcher</span><i>0.2.0</i></div>
    <div className="window-controls">
      <button aria-label="Свернуть" title="Свернуть" onClick={() => void handle.minimize()}><Minus size={15} /></button>
      <button aria-label={maximized ? 'Восстановить' : 'Развернуть'} title={maximized ? 'Восстановить' : 'Развернуть'} onClick={() => void handle.toggleMaximize()}>{maximized ? <span className="restore-glyph" /> : <Square size={12} />}</button>
      <button className="window-close" aria-label="Закрыть" title="Закрыть" onClick={() => void handle.close()}><X size={16} /></button>
    </div>
  </header>
  </>;
}
