export function ProgressBar({ value, label }: { value: number; label?: string }) {
  const safe = Math.max(0, Math.min(100, value));
  return <div className="progress-wrap"><div className="progress-track"><div className="progress-value" style={{ width: `${safe}%` }} /></div>{label && <span>{label}</span>}</div>;
}
