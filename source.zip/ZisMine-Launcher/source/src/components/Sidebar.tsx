import { Home, Settings, UserRound, Puzzle, Shirt } from 'lucide-react';

type Page = 'home' | 'accounts' | 'mods' | 'skins' | 'settings';
const items = [
  { id: 'home' as const, label: 'Главная', icon: Home },
  { id: 'accounts' as const, label: 'Аккаунт', icon: UserRound },
  { id: 'mods' as const, label: 'Моды', icon: Puzzle },
  { id: 'skins' as const, label: 'Гардероб', icon: Shirt },
  { id: 'settings' as const, label: 'Настройки', icon: Settings },
];

export function Sidebar({ page, onNavigate }: { page: Page; onNavigate: (page: Page) => void }) {
  return <aside className="sidebar">
    <div className="brand-lockup"><img src="/brand/zismine-logo.svg" alt="ZisMine" /></div>
    <div className="side-label">Лаунчер</div>
    <nav className="nav-list" aria-label="Основная навигация">
      {items.map(({ id, label, icon: Icon }) => <button key={id} className={`nav-item ${page === id ? 'active' : ''}`} onClick={() => onNavigate(id)}>
        <Icon size={19} strokeWidth={1.9} /><span>{label}</span>{page === id && <i />}
      </button>)}
    </nav>
    <div className="sidebar-bottom">
      <div className="sidebar-server-mark"><span className="brand-dot" /><div><strong>ZisMine</strong><small>Игровой сервер</small></div></div>
      <div className="sidebar-version">ZISMINE <span>v0.2.0</span></div>
    </div>
  </aside>;
}
