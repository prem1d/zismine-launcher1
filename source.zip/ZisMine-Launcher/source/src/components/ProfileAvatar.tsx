import { useState } from 'react';
import type { Profile } from '../types';

type Props = { profile?: Profile; className: string };

export function ProfileAvatar({ profile, className }: Props) {
  const [imageFailed, setImageFailed] = useState(false);
  const skin = profile?.kind === 'microsoft' ? profile.skin_url : null;
  if (skin && !imageFailed) {
    return <span className={`${className} skin-avatar`} aria-label={`Аватар ${profile?.name ?? ''}`}><img src={skin} alt="" onError={() => setImageFailed(true)} /></span>;
  }
  return <span className={className} aria-label={profile?.name ?? 'Нет профиля'}>{profile?.name?.slice(0, 1).toUpperCase() ?? '—'}</span>;
}
