import { invoke } from '@tauri-apps/api/core';
import { listen, type UnlistenFn } from '@tauri-apps/api/event';
import { open } from '@tauri-apps/plugin-dialog';
import { openUrl } from '@tauri-apps/plugin-opener';
import type { Bootstrap, DownloadProgress, ManifestVersion, ModInfo, Profile, Settings } from '../types';

export const isNative = '__TAURI_INTERNALS__' in window;

export const api = {
  bootstrap: () => invoke<Bootstrap>('get_bootstrap'),
  serverStatus: () => invoke<Bootstrap['server_status']>('get_server_status'),
  manifest: (filter: string) => invoke<ManifestVersion[]>('get_manifest_versions', { filter }),
  install: (version: string) => invoke<void>('install_fabric', { version }),
  cancelInstall: () => invoke<void>('cancel_install'),
  launch: (version: string) => invoke<{ pid: number; java_path: string }>('launch_game', { version }),
  createOffline: (name: string) => invoke<Profile>('create_offline_profile', { name }),
  deleteProfile: (id: string) => invoke<void>('delete_profile', { id }),
  setActive: (id: string) => invoke<void>('set_active_profile', { id }),
  saveSettings: (settings: Settings) => invoke<Settings>('save_settings', { settings }),
  resetSettings: () => invoke<Settings>('reset_settings'),
  clearTempFiles: () => invoke<number>('clear_temp_files'),
  removeVersion: (version: string) => invoke<void>('remove_version', { version }),
  openModsFolder: () => invoke<void>('open_mods_folder'),
  listMods: () => invoke<ModInfo[]>('list_mods'),
  setModEnabled: (fileName: string, enabled: boolean) => invoke<void>('set_mod_enabled', { fileName, enabled }),
  removeMod: (fileName: string) => invoke<void>('remove_mod', { fileName }),
  pickMinecraftDir: async () => { const result = await open({ directory: true, multiple: false, title: 'Выбрать папку Minecraft' }); return typeof result === 'string' ? result : null; },
  pickPng: async (title: string) => { const result = await open({ multiple: false, title, filters: [{ name: 'PNG', extensions: ['png'] }] }); return typeof result === 'string' ? result : null; },
  microsoftBegin: () => invoke<{ user_code: string; verification_uri: string; message: string; expires_in: number }>('microsoft_begin_login'),
  microsoftComplete: () => invoke<Profile>('microsoft_complete_login'),
  microsoftCancel: () => invoke<void>('cancel_microsoft_login'),
  openExternal: (url: string) => openUrl(url),
};

export function onDownloadProgress(callback: (progress: DownloadProgress) => void): Promise<UnlistenFn> {
  return listen<DownloadProgress>('download-progress', (event) => callback(event.payload));
}

export function onGameLog(callback: (line: string) => void): Promise<UnlistenFn> {
  return listen<string>('game-log', (event) => callback(event.payload));
}

export function onGameExit(callback: (exit: { pid: number; code: number | null }) => void): Promise<UnlistenFn> {
  return listen<{ pid: number; code: number | null }>('game-exit', (event) => callback(event.payload));
}
