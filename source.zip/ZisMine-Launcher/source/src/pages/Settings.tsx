import { useEffect, useState } from 'react';
import { Check, FolderOpen, Save } from 'lucide-react';
import type { Bootstrap, Settings as SettingsType } from '../types';
import { api } from '../services/native';

export function Settings({ data, onSaved, notify }: { data: Bootstrap; onSaved: () => void; notify: (message: string) => void }) {
  const [form, setForm] = useState<SettingsType>(data.settings);
  const [saving, setSaving] = useState(false);
  useEffect(() => setForm(data.settings), [data.settings]);

  const maxSafe = Math.max(1024, data.available_memory_mb - 2048);
  const displayedMax = Math.min(form.max_memory_mb, maxSafe);
  const patch = (partial: Partial<SettingsType>) => setForm(current => ({ ...current, ...partial }));

  const save = async () => {
    if (displayedMax < 1024 || displayedMax > maxSafe) {
      notify('Выбранный объём RAM превышает безопасный лимит.');
      return;
    }
    setSaving(true);
    try {
      await api.saveSettings({ ...form, max_memory_mb: displayedMax, min_memory_mb: Math.min(form.min_memory_mb, displayedMax), auto_java: true, java_path: '' });
      await onSaved();
      notify('Настройки сохранены.');
    } catch (error) { notify(`Не удалось сохранить настройки: ${String(error)}`); }
    finally { setSaving(false); }
  };

  const pickFolder = async () => {
    try { const path = await api.pickMinecraftDir(); if (path) patch({ minecraft_dir: path }); }
    catch (error) { notify(String(error)); }
  };

  return <div className="page-stack settings-page page-enter">
    <div className="settings-heading">
      <div><span className="home-section-label">ПАРАМЕТРЫ ИГРЫ</span><h1>Настройки</h1><p>Основные параметры игры. Java и Fabric настроятся автоматически.</p></div>
      <button className="play-button settings-save" onClick={() => void save()} disabled={saving}>{saving ? <span className="spinner" /> : <Save size={16} />}{saving ? 'Сохранение…' : 'Сохранить'}</button>
    </div>

    <section className="settings-card">
      <div className="settings-card-heading"><div><h2>Производительность</h2><p>Выделение оперативной памяти для Minecraft.</p></div><strong className="ram-value">{(displayedMax / 1024).toFixed(1)} <small>GB</small></strong></div>
      <input className="ram-slider" type="range" min="1024" max={maxSafe} step="256" value={displayedMax} onChange={e => patch({ max_memory_mb: Number(e.target.value), min_memory_mb: Math.min(form.min_memory_mb, Number(e.target.value)) })} />
      <div className="ram-scale"><span>1 GB</span><span>Доступно системе: {(data.available_memory_mb / 1024).toFixed(1)} GB</span><span>{(maxSafe / 1024).toFixed(1)} GB</span></div>
      <p className="settings-hint">Оставляем не менее 2 GB для Windows и фоновых программ. Для обычной игры начни с 4 GB.</p>
    </section>

    <section className="settings-card java-card">
      <div className="settings-card-heading"><div><h2>Java Runtime</h2><p>Java 17 будет загружена и настроена автоматически.</p></div><span className={`java-state ${data.java_runtime_installed ? 'installed' : ''}`}><i />{data.java_runtime_installed ? 'Готово' : 'Скачивается при запуске'}</span></div>
      <div className="java-runtime-info"><div className="java-badge">17</div><div><strong>Java 17</strong><span>{data.java_runtime_installed ? 'Уже установлена и будет использоваться для запуска.' : 'Загрузится с серверов Mojang при первом запуске игры.'}</span><code>{data.java_runtime_dir}</code></div><Check size={17} className="java-check" /></div>
      <p className="settings-hint">Java 17 хранится в папке <b>runtime</b> рядом с файлом лаунчера. Отдельно скачивать или настраивать Java не нужно.</p>
    </section>

    <details className="settings-advanced">
      <summary>Дополнительные настройки <span>Папка игры и параметры окна</span></summary>
      <div className="advanced-content">
        <label className="advanced-field"><span><strong>Папка Minecraft</strong><small>Здесь хранятся игровые файлы и миры.</small></span><div className="advanced-path"><input className="text-input" value={form.minecraft_dir} onChange={e => patch({ minecraft_dir: e.target.value })} /><button className="subtle-button" onClick={() => void pickFolder()} title="Выбрать папку"><FolderOpen size={16} /></button></div></label>
        <div className="advanced-field"><span><strong>Размер окна</strong><small>Разрешение при запуске игры.</small></span><div className="advanced-resolution"><input className="text-input" type="number" min="640" max="7680" value={form.width} onChange={e => patch({ width: Number(e.target.value) })} /><span>×</span><input className="text-input" type="number" min="480" max="4320" value={form.height} onChange={e => patch({ height: Number(e.target.value) })} /></div></div>
        <label className="advanced-field"><span><strong>Полноэкранный режим</strong><small>Открывать Minecraft на весь экран.</small></span><input type="checkbox" checked={form.fullscreen} onChange={e => patch({ fullscreen: e.target.checked })} /></label>

        <label className="advanced-field oauth-field"><span><strong>Microsoft OAuth Client ID</strong><small>Публичный ID приложения для авторизации Microsoft.</small></span><input className="text-input" value={form.oauth_client_id} onChange={e => patch({ oauth_client_id: e.target.value.trim() })} placeholder="Application (client) ID" /></label>
      </div>
    </details>
  </div>;
}
