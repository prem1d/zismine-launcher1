import { useState } from 'react';
import { Check, ImagePlus, Shirt, UserRound } from 'lucide-react';
import type { SkinData, SkinModel } from '../types';
import { api } from '../services/native';

function fileName(path: string | null) {
  return path?.split(/[\\/]/).pop() ?? '';
}

export function Skins({ notify }: { notify: (message: string) => void }) {
  const [skin, setSkin] = useState<SkinData>({ model: 'Classic', skinPath: null, capePath: null });

  const choosePng = async (kind: 'skinPath' | 'capePath') => {
    try {
      const path = await api.pickPng(kind === 'skinPath' ? 'Выбрать скин PNG' : 'Выбрать плащ PNG');
      if (path) setSkin(current => ({ ...current, [kind]: path }));
    } catch (error) {
      notify(`Не удалось выбрать PNG: ${String(error)}`);
    }
  };

  const setModel = (model: SkinModel) => setSkin(current => ({ ...current, model }));

  return <div className="page-stack page-enter wardrobe-page">
    <div className="page-title-row"><div><span className="panel-kicker">ПЕРСОНАЛИЗАЦИЯ</span><h1>Гардероб</h1><p>Выбери модель и подготовь файлы скина и плаща.</p></div></div>
    <section className="wardrobe-layout">
      <div className="panel wardrobe-preview-card">
        <div className="panel-heading"><div><span className="panel-kicker">ПРЕДПРОСМОТР</span><h2>Твой персонаж</h2></div><span className="wardrobe-model-tag">{skin.model}</span></div>
        <div className="skin-stage" role="img" aria-label={`Заглушка предпросмотра персонажа, модель ${skin.model}`}>
          <div className="skin-stage-grid" />
          <div className="skin-silhouette" aria-hidden="true"><i className="skin-head" /><i className="skin-body" /><i className="skin-arm skin-arm-left" /><i className="skin-arm skin-arm-right" /><i className="skin-leg skin-leg-left" /><i className="skin-leg skin-leg-right" /></div>
          <span className="skin-stage-caption"><UserRound size={14} /> 3D-предпросмотр появится здесь</span>
        </div>
        <div className="model-picker" aria-label="Модель персонажа">
          <span>Модель</span>
          <div><button className={skin.model === 'Classic' ? 'selected' : ''} aria-pressed={skin.model === 'Classic'} onClick={() => setModel('Classic')}>Classic</button><button className={skin.model === 'Slim' ? 'selected' : ''} aria-pressed={skin.model === 'Slim'} onClick={() => setModel('Slim')}>Slim</button></div>
        </div>
      </div>

      <div className="wardrobe-controls">
        <section className="panel wardrobe-upload-card">
          <span className="wardrobe-file-icon"><ImagePlus size={19} /></span>
          <div className="wardrobe-control-copy"><h2>Скин</h2><p>PNG-файл текстуры персонажа.</p></div>
          <button className="outline-button wardrobe-upload-button" onClick={() => void choosePng('skinPath')}><ImagePlus size={15} />{skin.skinPath ? 'Заменить скин' : 'Загрузить скин (.png)'}</button>
          <div className={`wardrobe-file-status ${skin.skinPath ? 'has-file' : ''}`}><span>{skin.skinPath ? <Check size={13} /> : <span className="file-empty-dot" />}</span><span title={skin.skinPath ?? ''}>{skin.skinPath ? fileName(skin.skinPath) : 'Файл не выбран'}</span></div>
        </section>
        <section className="panel wardrobe-upload-card">
          <span className="wardrobe-file-icon cape-icon"><Shirt size={19} /></span>
          <div className="wardrobe-control-copy"><h2>Плащ</h2><p>PNG-файл накидки для персонажа.</p></div>
          <button className="outline-button wardrobe-upload-button" onClick={() => void choosePng('capePath')}><ImagePlus size={15} />{skin.capePath ? 'Заменить плащ' : 'Загрузить плащ (.png)'}</button>
          <div className={`wardrobe-file-status ${skin.capePath ? 'has-file' : ''}`}><span>{skin.capePath ? <Check size={13} /> : <span className="file-empty-dot" />}</span><span title={skin.capePath ?? ''}>{skin.capePath ? fileName(skin.capePath) : 'Файл не выбран'}</span></div>
        </section>
        <p className="wardrobe-note">Выбранные пути хранятся в состоянии страницы. Сохранение в профиль и применение в игре подключаются отдельно.</p>
      </div>
    </section>
  </div>;
}
