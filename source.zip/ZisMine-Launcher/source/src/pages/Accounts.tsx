import { useState } from 'react';
import { Check, CirclePlus, Copy, KeyRound, ShieldCheck, Trash2, X, ExternalLink, LoaderCircle } from 'lucide-react';
import type { Bootstrap, Profile } from '../types';
import { api } from '../services/native';
import { ProfileAvatar } from '../components/ProfileAvatar';

export function Accounts({ data, onChanged, notify }: { data: Bootstrap; onChanged: () => void; notify: (message: string) => void }) {
  const [modal, setModal] = useState(false);
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);
  const [deviceCode, setDeviceCode] = useState<{ user_code: string; verification_uri: string; message: string; expires_in: number } | null>(null);
  const [authBusy, setAuthBusy] = useState(false);
  const active = data.profiles.find(p => p.id === data.active_profile_id);

  const create = async () => {
    setBusy(true);
    try { await api.createOffline(name.trim()); setName(''); setModal(false); await onChanged(); notify('Offline-профиль создан.'); }
    catch (error) { notify(String(error)); }
    finally { setBusy(false); }
  };
  const activate = async (p: Profile) => {
    try { await api.setActive(p.id); await onChanged(); notify(`Активен профиль ${p.name}.`); }
    catch (error) { notify(String(error)); }
  };
  const remove = async (p: Profile) => {
    if (!window.confirm(`Удалить профиль ${p.name}?`)) return;
    try { await api.deleteProfile(p.id); await onChanged(); notify('Профиль удалён.'); }
    catch (error) { notify(String(error)); }
  };
  const validName = /^[A-Za-z0-9_]{3,16}$/.test(name.trim());
  const beginMicrosoft = async () => {
    setAuthBusy(true);
    try { const response = await api.microsoftBegin(); setDeviceCode(response); await api.openExternal(response.verification_uri); }
    catch (error) { notify(`Не удалось начать Microsoft-вход: ${String(error)}`); }
    finally { setAuthBusy(false); }
  };
  const completeMicrosoft = async () => {
    setAuthBusy(true);
    try { await api.microsoftComplete(); setDeviceCode(null); await onChanged(); notify('Microsoft-аккаунт успешно добавлен.'); }
    catch (error) { notify(`Microsoft-вход не завершён: ${String(error)}`); }
    finally { setAuthBusy(false); }
  };
  const cancelMicrosoft = async () => { try { await api.microsoftCancel(); } finally { setDeviceCode(null); } };

  return <div className="page-stack page-enter">
    <div className="page-title-row"><div><span className="panel-kicker">УПРАВЛЕНИЕ ДОСТУПОМ</span><h1>Аккаунты</h1><p>Управляй игровыми профилями локально и безопасно.</p></div><button className="primary-small" onClick={() => setModal(true)}><CirclePlus size={16} /> Добавить профиль</button></div>
    <section className="panel account-active-panel">
      <div className="panel-heading"><div><span className="panel-kicker">ТЕКУЩИЙ ПРОФИЛЬ</span><h2>Выбранный аккаунт</h2></div><span className={`state-tag ${active?.kind === 'microsoft' ? 'state-good' : 'state-muted'}`}><i />{active?.kind === 'microsoft' ? 'Лицензионный аккаунт' : active ? 'Локальный профиль' : 'Нет профиля'}</span></div>
      {active ? <div className="active-profile"><ProfileAvatar profile={active} className="profile-avatar large" /><div className="profile-primary"><strong>{active.name}</strong><span>{active.kind === 'offline' ? 'Локальный профиль · UUID' : 'Аккаунт Microsoft'}</span><code>{active.uuid}</code></div><span className="active-check"><Check size={16} /> Активен</span></div> : <div className="no-profile"><img src="/illustrations/no-account.svg" alt="" /><div><strong>Пока нет игрового профиля</strong><span>Создай локальный профиль или подключи Microsoft после настройки входа.</span><button className="primary-small" onClick={() => setModal(true)}><CirclePlus size={15} /> Создать локальный профиль</button></div></div>}
    </section>
    <section className="panel account-list-panel">
      <div className="panel-heading"><div><span className="panel-kicker">ТВОИ ПРОФИЛИ</span><h2>Сохранённые аккаунты</h2></div><span className="count-tag">{data.profiles.length}</span></div>
      {data.profiles.length ? <div className="account-list">{data.profiles.map(p => <div className="account-row" key={p.id}>
        <ProfileAvatar profile={p} className="profile-avatar" /><div className="account-row-info"><strong>{p.name}</strong><span>{p.kind === 'offline' ? 'Локальный профиль' : 'Microsoft'}</span></div>
        {p.id === data.active_profile_id ? <span className="selected-label"><Check size={13} /> Выбран</span> : <button className="outline-button compact" onClick={() => void activate(p)}>Выбрать</button>}
        <button className="row-icon-button danger" onClick={() => void remove(p)} title="Удалить профиль"><Trash2 size={15} /></button>
      </div>)}</div> : <div className="list-empty">Нет сохранённых профилей.</div>}
    </section>
    {active?.kind === 'microsoft' ? <section className="panel microsoft-panel microsoft-signed-panel" aria-live="polite">
      <ProfileAvatar profile={active} className="profile-avatar microsoft-signed-avatar" />
      <div className="microsoft-copy"><strong>Вы вошли как {active.name}</strong><span>Microsoft · Лицензионный аккаунт Minecraft Java Edition.</span></div>
      <span className="state-tag state-good"><i />Подключено</span>
    </section> : <section className="panel microsoft-panel">
      <div className="microsoft-icon"><KeyRound size={20} /></div><div className="microsoft-copy"><strong>Лицензионный аккаунт Microsoft</strong><span>Официальный вход Microsoft с проверкой профиля и лицензии Minecraft Java Edition.</span><small>Нужен Client ID приложения Microsoft. Пароль от аккаунта лаунчер не запрашивает.</small></div>
      <button className="microsoft-login-button" disabled={!data.settings.oauth_client_id.trim() || authBusy} onClick={() => void beginMicrosoft()}>
        {authBusy ? <><LoaderCircle size={15} className="spin" /> Авторизация...</> : <><span className="ms-logo" aria-hidden="true"><i /><i /><i /><i /></span>Войти через Microsoft</>}
      </button>
    </section>}
    <div className="info-note"><span>!</span><p>Локальный профиль не является лицензией Minecraft. Он подходит для локального тестирования, одиночной игры и серверов, которые явно разрешают offline-аутентификацию. Он не авторизуется на серверах с online-mode.</p></div>

    {deviceCode && <div className="modal-backdrop"><div className="modal-card"><div className="modal-header"><div><span className="panel-kicker">ВХОД MICROSOFT</span><h2>Подтверди вход</h2></div><button className="icon-button" onClick={() => void cancelMicrosoft()}><X size={18} /></button></div><p className="modal-description">Открылся браузер Microsoft. Введите код на странице подтверждения и вернитесь сюда.</p><a className="auth-link" href={deviceCode.verification_uri} onClick={e => { e.preventDefault(); void api.openExternal(deviceCode.verification_uri); }}>{deviceCode.verification_uri} <ExternalLink size={13} /></a><div className="device-code">{deviceCode.user_code}<button onClick={() => { void navigator.clipboard.writeText(deviceCode.user_code); notify('Код скопирован.'); }}><Copy size={15} /></button></div><div className="modal-warning"><ShieldCheck size={16} /> После подтверждения нажмите «Завершить вход». Лаунчер проверит профиль и лицензию Minecraft Java.</div><div className="modal-actions"><button className="outline-button" onClick={() => void cancelMicrosoft()}>Отмена</button><button className="primary-small" disabled={authBusy} onClick={() => void completeMicrosoft()}>{authBusy ? <><LoaderCircle size={14} className="spin" /> Проверяем...</> : 'Завершить вход'}</button></div></div></div>}
    {modal && <div className="modal-backdrop" onMouseDown={e => e.target === e.currentTarget && setModal(false)}><div className="modal-card">
      <div className="modal-header"><div><span className="panel-kicker">НОВЫЙ ЛОКАЛЬНЫЙ ПРОФИЛЬ</span><h2>Локальный профиль</h2></div><button className="icon-button" onClick={() => setModal(false)}><X size={18} /></button></div>
      <p className="modal-description">Имя должно содержать 3–16 символов: латинские буквы, цифры или нижнее подчёркивание.</p>
      <label className="field-label">Игровой ник</label><input className="text-input" autoFocus maxLength={16} value={name} onChange={e => setName(e.target.value.replace(/[^A-Za-z0-9_]/g, ''))} placeholder="Например, ZisPlayer" />
      <div className="modal-warning"><ShieldCheck size={16} /> Локальный профиль не подтверждает владение Minecraft.</div>
      <div className="modal-actions"><button className="outline-button" onClick={() => setModal(false)}>Отмена</button><button className="primary-small" disabled={!validName || busy} onClick={() => void create()}>{busy ? 'Создание...' : 'Создать профиль'}</button></div>
    </div></div>}
  </div>;
}
