import { useState } from 'react';
import { Check, Copy, Play, Server, ShieldCheck, UserRound, X, ArrowUpRight, Cpu, Puzzle, Zap } from 'lucide-react';
import type { Bootstrap, Profile } from '../types';
import { ProgressBar } from '../components/ProgressBar';

export function Home({ data, busy, gameRunning, progress, onPlay, onCancel, onAccounts, notify }: {
  data: Bootstrap; busy: boolean; gameRunning: boolean; progress: number; onPlay: (boostFps: boolean) => void; onCancel: () => void; onAccounts: () => void; notify: (message: string) => void;
}) {
  const [boostFps, setBoostFps] = useState(false);
  const profile = data.profiles.find((p: Profile) => p.id === data.active_profile_id);
  const serverReady = Boolean(data.server.address.trim());
  const serverAddress = `${data.server.address}${data.server.port && data.server.port !== 25565 ? `:${data.server.port}` : ''}`;
  const copyAddress = async () => {
    if (!serverReady) return notify('Адрес сервера ещё не настроен.');
    try { await navigator.clipboard.writeText(serverAddress); notify('Адрес сервера скопирован.'); }
    catch { notify('Не удалось скопировать адрес.'); }
  };
  return <div className="page-stack home-page page-enter">
    <section className="home-hero">
      <div className="hero-grain" />
      <div className="home-hero-content">
        <div className="home-eyebrow"><span className="pulse-dot" /> ТВОЙ ИГРОВОЙ МИР <span className="home-version">1.20.1 · FABRIC</span></div>
        <h1>Добро пожаловать<br /><em>на ZisMine.</em></h1>
        <p>Всё готово для следующего приключения.</p>
        <div className="home-primary-actions">
          <button className="play-button home-play" onClick={() => onPlay(boostFps)} disabled={busy || gameRunning || !profile}>
            {busy ? <span className="spinner" /> : gameRunning ? <Check size={19} /> : <Play size={19} fill="currentColor" />}
            {busy ? 'Готовим игру…' : gameRunning ? 'Игра запущена' : 'Играть'}
          </button>
          <button className={`fps-boost ${boostFps ? 'is-on' : ''}`} role="switch" aria-checked={boostFps}
            onClick={() => setBoostFps(value => !value)} title="Включить оптимизированный профиль для слабых ПК">
            <span className="fps-boost-icon"><Zap size={17} /></span>
            <span className="fps-boost-copy"><strong>Буст FPS</strong><small>{boostFps ? 'Включён' : 'Для слабых ПК'}</small></span>
            <span className="fps-boost-track" aria-hidden="true"><i /></span>
          </button>
        </div>
        {!profile && <button className="home-account-link" onClick={onAccounts}><UserRound size={15} /> Подключить игровой аккаунт <ArrowUpRight size={14} /></button>}
        {busy && <div className="home-progress"><ProgressBar value={progress} label={`${Math.round(progress)}%`} /><button className="progress-cancel" onClick={onCancel}><X size={14} /> Отменить</button></div>}
        <div className="home-assurance"><ShieldCheck size={16} /> Fabric, Fabric API и Java 17 устанавливаются автоматически</div>
      </div>
      <div className="home-hero-version">ZISMINE <span>·</span> FABRIC EDITION</div>
    </section>

    <section className="home-status-strip">
      <div className="game-status-icon"><Puzzle size={21} /></div>
      <div className="game-status-copy"><strong>Minecraft 1.20.1</strong><span>Fabric Loader · Fabric API</span></div>
      <span className={`state-tag ${data.installed_versions.includes('1.20.1') ? 'state-good' : 'state-muted'}`}><i />{data.installed_versions.includes('1.20.1') ? 'Готово к запуску' : 'Установится при первом запуске'}</span>
      <div className="status-divider" />
      <div className="runtime-status"><Cpu size={20} /><div><strong>Java 17</strong><span>{data.java_runtime_installed ? 'Установлена' : 'Установится автоматически'}</span></div></div>
    </section>

    <section className="home-server-card">
      <div className="home-server-main"><span className="home-section-label">ТВОЙ СЕРВЕР</span><h2>{data.server.name || 'ZisMine'}</h2><p>{data.server.description || 'Твой мир. Твои правила.'}</p></div>
      <div className="home-server-meta">
        <span className={`server-status ${data.server_status ? (data.server_status.online ? 'online' : 'offline') : 'unknown'}`}><i />{data.server_status ? (data.server_status.online ? 'Сервер онлайн' : 'Сервер офлайн') : 'Статус не настроен'}</span>
        {data.server_status?.players_online != null && <span className="home-player-count">{data.server_status.players_online}{data.server_status.players_max != null ? ` / ${data.server_status.players_max}` : ''} игроков</span>}
        <div className="home-server-address"><Server size={16} /><span>{serverReady ? serverAddress : 'Адрес сервера не задан'}</span>{serverReady && <button onClick={() => void copyAddress()} title="Скопировать адрес"><Copy size={15} /></button>}</div>
      </div>
    </section>
  </div>;
}
