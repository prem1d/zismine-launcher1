import { useEffect, useState } from 'react';
import { Box, Check, FolderOpen, Power, Puzzle, RefreshCw, ShieldCheck, Trash2 } from 'lucide-react';
import { api } from '../services/native';
import type { ModInfo } from '../types';

export function Mods({ notify }: { notify: (message: string) => void }) {
  const [mods, setMods] = useState<ModInfo[]>([]);
  const [loading, setLoading] = useState(true);
  const [working, setWorking] = useState<string | null>(null);
  const refresh = async () => { setLoading(true); try { setMods(await api.listMods()); } catch (e) { notify(`Не удалось прочитать список модов: ${String(e)}`); } finally { setLoading(false); } };
  useEffect(() => { void refresh(); }, []);
  const openFolder = async () => { try { await api.openModsFolder(); } catch (e) { notify(`Не удалось открыть папку модов: ${String(e)}`); } };
  const toggle = async (mod: ModInfo) => { setWorking(mod.file_name); try { await api.setModEnabled(mod.file_name, !mod.enabled); await refresh(); notify(mod.enabled ? 'Мод отключён.' : 'Мод включён.'); } catch (e) { notify(String(e)); } finally { setWorking(null); } };
  const remove = async (mod: ModInfo) => { if (mod.essential) return; if (!window.confirm(`Удалить мод «${mod.name}»?`)) return; setWorking(mod.file_name); try { await api.removeMod(mod.file_name); await refresh(); notify('Мод удалён.'); } catch (e) { notify(String(e)); } finally { setWorking(null); } };
  return <div className="page-stack mods-page page-enter">
    <div className="page-title-row"><div><span className="panel-kicker">ВАША СБОРКА</span><h1>Моды</h1><p>Управляйте дополнениями для Minecraft 1.20.1 Fabric.</p></div><div className="page-actions"><button className="outline-button refresh-button" onClick={openFolder}><FolderOpen size={16} /> Открыть папку</button><button className="outline-button refresh-button" onClick={() => void refresh()} disabled={loading}><RefreshCw size={16} className={loading ? 'spin' : ''} /> Обновить</button></div></div>
    <section className="mods-summary"><div className="mods-summary-icon"><Puzzle size={22} /></div><div><strong>Fabric Loader</strong><span>Основной загрузчик · Minecraft 1.20.1</span></div><span className="state-tag state-good"><i /> Используется</span></section>
    <section className="panel mods-list-panel"><div className="panel-heading"><div><span className="panel-kicker">УСТАНОВЛЕННЫЕ ДОПОЛНЕНИЯ</span><h2>В вашей папке mods</h2></div><span className="count-tag">{mods.length}</span></div>
      {loading ? <div className="mods-empty"><span className="spinner" /><p>Читаем список модов…</p></div> : mods.length === 0 ? <div className="mods-empty"><Box size={29} /><strong>Пока нет дополнительных модов</strong><p>Fabric API устанавливается автоматически. Остальные моды можно добавить в папку mods этого профиля игры.</p></div> : <div className="mods-list">{mods.map(mod => <article className="mod-row" key={`${mod.file_name}:${mod.enabled}`}><div className="mod-symbol"><Puzzle size={18} /></div><div className="mod-meta"><strong>{mod.name}</strong><span>{mod.version} · {mod.file_name}</span><small>{mod.description}</small></div><span className={`mod-compat ${mod.compatibility}`}>{mod.compatibility === 'compatible' ? 'Совместим' : mod.compatibility === 'incompatible' ? 'Другая версия' : 'Версия не указана'}</span>{mod.essential ? <span className="mod-required"><ShieldCheck size={14} /> Обязательный</span> : <span className={`mod-state ${mod.enabled ? 'enabled' : 'disabled'}`}>{mod.enabled ? 'Включён' : 'Выключен'}</span>}<button className="mod-action" disabled={!!working || mod.essential} title={mod.enabled ? 'Отключить' : 'Включить'} onClick={() => void toggle(mod)}>{working === mod.file_name ? <span className="spinner" /> : <Power size={16} />}</button><button className="mod-action danger" disabled={!!working || mod.essential} title="Удалить мод" onClick={() => void remove(mod)}><Trash2 size={16} /></button></article>)}</div>}
    </section>
    <p className="mods-note"><Check size={15} /> Fabric API является обязательной частью сборки. Лаунчер защищает его от случайного удаления.</p>
  </div>;
}
