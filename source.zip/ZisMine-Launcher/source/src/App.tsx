import { useEffect, useMemo, useState } from 'react';
import { AlertCircle, CheckCircle2, DownloadCloud, X } from 'lucide-react';
import { Sidebar } from './components/Sidebar';
import { Topbar } from './components/Topbar';
import { WindowChrome } from './components/WindowChrome';
import { Home } from './pages/Home';
import { Accounts } from './pages/Accounts';
import { Settings } from './pages/Settings';
import { Mods } from './pages/Mods';
import { Skins } from './pages/Skins';
import { api, isNative, onDownloadProgress, onGameExit, onGameLog } from './services/native';
import type { Bootstrap, DownloadProgress } from './types';

type Page = 'home' | 'accounts' | 'mods' | 'skins' | 'settings';
type Notice = { id: number; message: string; kind: 'success' | 'error' | 'info' };

export default function App() {
  const [page, setPage] = useState<Page>('home');
  const [data, setData] = useState<Bootstrap | null>(null);
  const [startupError, setStartupError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState<DownloadProgress | null>(null);
  const [notices, setNotices] = useState<Notice[]>([]);
  const [consoleLines, setConsoleLines] = useState<string[]>([]);
  const [gameRunning, setGameRunning] = useState(false);

  const notify = (message: string, kind: Notice['kind'] = 'info') => {
    const id = Date.now() + Math.floor(Math.random() * 1000);
    setNotices(items => [...items.slice(-3), { id, message, kind }]);
    window.setTimeout(() => setNotices(items => items.filter(item => item.id !== id)), 5200);
  };

  const reload = async () => {
    const next = await api.bootstrap();
    setData(next);
    void api.serverStatus().then(status => {
      setData(current => current ? { ...current, server_status: status } : current);
    }).catch(() => setData(current => current ? { ...current, server_status: null } : current));
  };

  useEffect(() => {
    if (!isNative) {
      setStartupError('Открой приложение через Tauri. В браузерном режиме системный движок Minecraft недоступен.');
      return;
    }
    void reload().catch(error => setStartupError(String(error)));
    let unlistenProgress: (() => void) | undefined;
    let unlistenLog: (() => void) | undefined;
    let unlistenExit: (() => void) | undefined;
    void onDownloadProgress(p => setProgress(p)).then(fn => { unlistenProgress = fn; });
    void onGameLog(line => setConsoleLines(lines => [...lines.slice(-299), line])).then(fn => { unlistenLog = fn; });
    void onGameExit(event => { setGameRunning(false); notify(`Minecraft завершился (код ${event.code ?? 'неизвестен'}).`, event.code === 0 ? 'success' : 'error'); }).then(fn => { unlistenExit = fn; });
    return () => { unlistenProgress?.(); unlistenLog?.(); unlistenExit?.(); };
  }, []);

  const activeProfile = useMemo(() => data?.profiles.find(p => p.id === data.active_profile_id), [data]);

  const play = async (boostFps = false) => {
    if (!data) return;
    if (gameRunning) { notify('Minecraft уже запущен.', 'info'); return; }
    if (!data.active_profile_id) { setPage('accounts'); notify('Сначала создай или выбери игровой профиль.', 'error'); return; }
    setBusy(true);
    try {
      // TODO: перед запуском передать boostFps в Rust-команду готового оптимизированного профиля.
      // Сейчас переключатель сохраняет флаг в UI, но не меняет игровые файлы.
      if (boostFps) { /* интеграция FPS-профиля появится вместе с backend-командой */ }
      const selected = data.settings.selected_version;
      if (!data.installed_versions.includes(selected)) {
        await api.install(selected);
        await reload();
      }
      const result = await api.launch(selected);
      setGameRunning(true);
      notify(`Minecraft запущен. PID: ${result.pid}`, 'success');
    } catch (error) {
      notify(String(error), 'error');
    } finally {
      setBusy(false);
      setProgress(null);
    }
  };

  if (startupError) return <div className="startup-screen"><img src="/brand/zismine-logo.svg" alt="ZisMine" /><div className="startup-error"><AlertCircle size={20} /><strong>Не удалось запустить движок</strong><p>{startupError}</p><span>Для разработки используй <code>npm run tauri dev</code> после установки Rust и системных зависимостей.</span></div></div>;
  if (!data) return <div className="startup-screen"><img src="/brand/zismine-logo.svg" alt="ZisMine" /><span className="spinner" /><p>Подготовка рабочего пространства...</p></div>;

  return <div className="app-shell">
    <WindowChrome />
    <div className="app-layout">
    <Sidebar page={page} onNavigate={setPage} />
    <div className="main-shell">
      <Topbar profile={activeProfile} title={page === 'home' ? 'Главная' : page === 'accounts' ? 'Аккаунт' : page === 'mods' ? 'Моды' : page === 'skins' ? 'Гардероб' : 'Настройки'} onAccounts={() => setPage('accounts')} />
      <main className="main-content">
        {page === 'home' && <Home data={data} busy={busy} gameRunning={gameRunning} progress={progress ? (progress.total_bytes ? progress.downloaded_bytes / progress.total_bytes * 100 : progress.total ? progress.completed / progress.total * 100 : 0) : 0} onPlay={(boostFps) => void play(boostFps)} onCancel={() => void api.cancelInstall().then(() => notify('Запрос на отмену отправлен.'))} onAccounts={() => setPage('accounts')} notify={notify} />}
        {page === 'accounts' && <Accounts data={data} onChanged={reload} notify={notify} />}
        {page === 'mods' && <Mods notify={notify} />}
        {page === 'skins' && <Skins notify={notify} />}
        {page === 'settings' && <Settings data={data} onSaved={reload} notify={notify} />}
      </main>
      <footer className="main-footer"><span>© 2026 ZisMine Launcher</span><span>{gameRunning ? <><i className="footer-live-dot" /> Minecraft запущен</> : 'Сделано для комфортной игры'}</span></footer>
    </div>
    </div>
    <div className="toast-stack">{notices.map(notice => <div className={`toast toast-${notice.kind}`} key={notice.id}><span>{notice.kind === 'success' ? <CheckCircle2 size={17} /> : notice.kind === 'error' ? <AlertCircle size={17} /> : <DownloadCloud size={17} />}</span><p>{notice.message}</p><button onClick={() => setNotices(items => items.filter(item => item.id !== notice.id))}><X size={14} /></button></div>)}</div>
    {data.settings.show_console && consoleLines.length > 0 && <div className="console-drawer"><div className="console-head"><strong>Консоль Minecraft</strong><button onClick={() => setConsoleLines([])}><X size={15} /></button></div><div className="console-lines">{consoleLines.map((line, i) => <code key={i}>{line}</code>)}</div></div>}
  </div>;
}
