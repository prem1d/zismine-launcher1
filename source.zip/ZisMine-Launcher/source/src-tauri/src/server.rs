use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct ServerConfig {
    pub name: String,
    pub address: String,
    pub port: u16,
    pub recommended_version: String,
    pub description: String,
    pub website: String,
    pub telegram: String,
    pub discord: String,
    pub news_url: String,
    pub status_api: String,
}

impl Default for ServerConfig {
    fn default() -> Self {
        Self {
            name: "ZisMine".into(),
            address: String::new(),
            port: 25565,
            recommended_version: "1.20.1 Fabric".into(),
            description: String::new(),
            website: String::new(),
            telegram: String::new(),
            discord: String::new(),
            news_url: String::new(),
            status_api: String::new(),
        }
    }
}
