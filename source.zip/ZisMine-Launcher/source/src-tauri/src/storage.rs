use anyhow::{Context, Result};
use serde::{de::DeserializeOwned, Serialize};
use std::{fs, path::{Path, PathBuf}};
use tauri::{AppHandle, Manager};

pub fn app_data_dir(app: &AppHandle) -> Result<PathBuf> {
    let path = app.path().app_data_dir().context("Не удалось определить системную папку данных приложения")?;
    fs::create_dir_all(&path).with_context(|| format!("Не удалось создать {}", path.display()))?;
    Ok(path)
}


/// Base directory for the managed Java runtime. On Windows the runtime lives
/// beside the installed launcher executable; the NSIS package is configured
/// for current-user installation so this directory is writable without admin.
/// On macOS/Linux, use the per-user app-data directory instead of writing into
/// a signed app bundle or a system-managed installation directory.
pub fn runtime_base_dir(_app: &AppHandle) -> Result<PathBuf> {
    #[cfg(target_os = "windows")]
    {
        let executable = std::env::current_exe().context("Не удалось определить путь к файлу лаунчера")?;
        let parent = executable.parent().context("У файла лаунчера не найдена родительская папка")?;
        Ok(parent.to_path_buf())
    }
    #[cfg(not(target_os = "windows"))]
    {
        let path = _app.path().app_data_dir().context("Не удалось определить системную папку данных приложения")?;
        fs::create_dir_all(&path).with_context(|| format!("Не удалось создать {}", path.display()))?;
        Ok(path)
    }
}

pub fn java_runtime_dir(app: &AppHandle) -> Result<PathBuf> {
    Ok(runtime_base_dir(app)?.join("runtime"))
}

pub fn read_json<T: DeserializeOwned>(path: &Path) -> Result<T> {
    let content = fs::read(path).with_context(|| format!("Не удалось прочитать {}", path.display()))?;
    serde_json::from_slice(&content).with_context(|| format!("Некорректный JSON: {}", path.display()))
}

pub fn write_json<T: Serialize>(path: &Path, value: &T) -> Result<()> {
    if let Some(parent) = path.parent() { fs::create_dir_all(parent)?; }
    let bytes = serde_json::to_vec_pretty(value)?;
    let file_name = path.file_name().and_then(|name| name.to_str()).unwrap_or("data.json");
    let temporary = path.with_file_name(format!(".{file_name}.{}.tmp", uuid::Uuid::new_v4()));
    fs::write(&temporary, bytes).with_context(|| format!("Не удалось записать {}", temporary.display()))?;
    match fs::rename(&temporary, path) {
        Ok(()) => Ok(()),
        Err(first_error) => {
            // Windows rename does not replace an existing destination; remove it and retry.
            if path.exists() {
                fs::remove_file(path).with_context(|| format!("Не удалось заменить {}", path.display()))?;
                fs::rename(&temporary, path).with_context(|| format!("Не удалось установить {}", path.display()))?;
                Ok(())
            } else {
                let _ = fs::remove_file(&temporary);
                Err(first_error).with_context(|| format!("Не удалось заменить {}", path.display()))
            }
        }
    }
}
