use anyhow::{bail, Context, Result};
use serde_json::Value;
use std::{fs, path::{Component, Path, PathBuf}};
use tauri::AppHandle;
use tokio_util::sync::CancellationToken;
use zip::ZipArchive;

use super::{download::{download_batch, DownloadItem}, manifest::{fetch_manifest, fetch_version_json, ensure_mojang_url, required_java_major}, runtime::ensure_runtime};
use crate::{settings::Settings, storage::{app_data_dir, read_json, runtime_base_dir, write_json}};

pub const SUPPORTED_VERSION: &str = "1.20.1";
const FABRIC_META_BASE: &str = "https://meta.fabricmc.net/v2/versions/loader/1.20.1";
const FABRIC_API_MAVEN_METADATA: &str = "https://maven.fabricmc.net/net/fabricmc/fabric-api/fabric-api/maven-metadata.xml";

async fn fetch_fabric_profile(client: &reqwest::Client) -> Result<(Value, String)> {
    let response = client.get(FABRIC_META_BASE).send().await
        .context("Не удалось получить версии Fabric Loader")?
        .error_for_status().context("Fabric Meta вернул HTTP-ошибку")?;
    let versions: Vec<Value> = response.json().await.context("Некорректный список Fabric Loader")?;
    let selected = versions.iter().find(|entry| {
        entry.pointer("/loader/stable").and_then(Value::as_bool) == Some(true)
    }).or_else(|| versions.first()).context("Fabric Meta не вернул ни одной версии Loader для Minecraft 1.20.1")?;
    let loader_version = selected.pointer("/loader/version").and_then(Value::as_str)
        .context("Fabric Meta не вернул номер Loader")?.to_string();
    let url = format!("{FABRIC_META_BASE}/{loader_version}/profile/json");
    let profile: Value = client.get(&url).send().await
        .context("Не удалось получить профиль Fabric Loader")?
        .error_for_status().context("Fabric profile endpoint вернул HTTP-ошибку")?
        .json().await.context("Не удалось разобрать профиль Fabric Loader")?;
    let inherits = profile.get("inheritsFrom").and_then(Value::as_str).unwrap_or_default();
    if inherits != SUPPORTED_VERSION {
        bail!("Fabric Loader вернул профиль для другой версии Minecraft: {inherits}.");
    }
    let main_class = profile.get("mainClass").and_then(Value::as_str).unwrap_or_default();
    if !main_class.starts_with("net.fabricmc.loader.") {
        bail!("Fabric Loader вернул неожиданный mainClass.");
    }
    Ok((profile, loader_version))
}

async fn fetch_fabric_api(client: &reqwest::Client) -> Result<(String, String, String)> {
    let xml = client.get(FABRIC_API_MAVEN_METADATA).send().await
        .context("Не удалось получить список версий Fabric API")?
        .error_for_status().context("Maven Fabric вернул HTTP-ошибку")?
        .text().await.context("Не удалось прочитать Maven metadata Fabric API")?;
    let versions = xml.split("<version>").skip(1)
        .filter_map(|chunk| chunk.split("</version>").next())
        .map(str::trim)
        .filter(|version| version.ends_with("+1.20.1"))
        .collect::<Vec<_>>();
    let version = versions.last().context("В Maven Fabric API не найдена версия, совместимая с Minecraft 1.20.1")?.to_string();
    let relative = format!("net/fabricmc/fabric-api/fabric-api/{version}/fabric-api-{version}.jar");
    let url = format!("https://maven.fabricmc.net/{relative}");
    let sha1_text = client.get(format!("{url}.sha1")).send().await
        .context("Не удалось получить SHA-1 Fabric API")?
        .error_for_status().context("Fabric API checksum endpoint вернул HTTP-ошибку")?
        .text().await.context("Не удалось прочитать SHA-1 Fabric API")?;
    let sha1 = sha1_text.split_whitespace().next().unwrap_or_default().to_string();
    if sha1.len() != 40 || !sha1.bytes().all(|c| c.is_ascii_hexdigit()) {
        bail!("Fabric API вернул некорректную контрольную сумму SHA-1.");
    }
    Ok((version, url, sha1))
}

fn merge_fabric_profile(mut vanilla: Value, fabric: Value) -> Result<Value> {
    let main_class = fabric.get("mainClass").and_then(Value::as_str)
        .context("В профиле Fabric отсутствует mainClass")?.to_string();
    let mut libraries = vanilla.get("libraries").and_then(Value::as_array).cloned().unwrap_or_default();
    if let Some(extra) = fabric.get("libraries").and_then(Value::as_array) {
        let mut names = libraries.iter().filter_map(|item| item.get("name").and_then(Value::as_str).map(ToOwned::to_owned)).collect::<std::collections::HashSet<_>>();
        for library in extra {
            if let Some(name) = library.get("name").and_then(Value::as_str) {
                if names.insert(name.to_string()) { libraries.push(library.clone()); }
            }
        }
    }
    vanilla["libraries"] = Value::Array(libraries);
    vanilla["mainClass"] = Value::String(main_class);

    let vanilla_arguments = vanilla.get("arguments").cloned().unwrap_or_else(|| serde_json::json!({"game": [], "jvm": []}));
    let fabric_arguments = fabric.get("arguments").cloned().unwrap_or_else(|| serde_json::json!({}));
    let mut merged_arguments = vanilla_arguments;
    for key in ["game", "jvm"] {
        let mut target = merged_arguments.get(key).and_then(Value::as_array).cloned().unwrap_or_default();
        if let Some(extra) = fabric_arguments.get(key).and_then(Value::as_array) { target.extend(extra.iter().cloned()); }
        merged_arguments[key] = Value::Array(target);
    }
    vanilla["arguments"] = merged_arguments;
    vanilla["zismineLoader"] = serde_json::json!({"type":"fabric", "minecraft":"1.20.1"});
    Ok(vanilla)
}


pub async fn install_fabric(app: AppHandle, client: reqwest::Client, version_id: &str, cancel: CancellationToken) -> Result<()> {
    if version_id != SUPPORTED_VERSION { bail!("Поддерживается только Minecraft {SUPPORTED_VERSION}."); }
    validate_version_id(version_id)?;
    let app_dir = app_data_dir(&app)?;
    let settings_path = app_dir.join("settings.json");
    let mut settings = if settings_path.exists() { read_json::<Settings>(&settings_path)? } else { Settings::default() };
    let root = PathBuf::from(&settings.minecraft_dir);
    fs::create_dir_all(root.join("versions"))?;

    let manifest = fetch_manifest(&client).await?;
    let manifest_version = manifest.versions.iter().find(|entry| entry.id == version_id)
        .with_context(|| format!("Версия {version_id} отсутствует в официальном Version Manifest."))?;
    let vanilla_metadata = fetch_version_json(&client, &manifest_version.url, manifest_version.sha1.as_deref()).await?;
    let metadata_id = vanilla_metadata.get("id").and_then(Value::as_str).unwrap_or_default();
    if metadata_id != SUPPORTED_VERSION { bail!("Mojang вернул неожиданные метаданные версии: {metadata_id}."); }
    let java_major = required_java_major(&vanilla_metadata, version_id)?;
    let (fabric_profile, fabric_loader_version) = fetch_fabric_profile(&client).await?;
    let (fabric_api_version, fabric_api_url, fabric_api_sha1) = fetch_fabric_api(&client).await?;
    let metadata = merge_fabric_profile(vanilla_metadata.clone(), fabric_profile)?;
    let version_dir = root.join("versions").join(version_id);
    fs::create_dir_all(&version_dir)?;
    // Remove a previous completion marker before repairing/reinstalling. A failed
    // retry must never leave a damaged installation looking ready to launch.
    let install_marker = version_dir.join(".zismine-installed.json");
    if install_marker.exists() { fs::remove_file(&install_marker)?; }
    let metadata_path = version_dir.join(format!("{version_id}.json"));
    fs::write(&metadata_path, serde_json::to_vec_pretty(&metadata)?)?;

    let mut downloads = Vec::<DownloadItem>::new();
    let client_download = vanilla_metadata.pointer("/downloads/client").context("В метаданных версии отсутствует client download")?;
    let client_url = json_string(client_download, "url")?;
    ensure_mojang_url(&client_url)?;
    downloads.push(DownloadItem {
        url: client_url,
        relative_path: PathBuf::from(format!("versions/{version_id}/{version_id}.jar")),
        sha1: client_download.get("sha1").and_then(Value::as_str).map(ToOwned::to_owned),
        size: client_download.get("size").and_then(Value::as_u64).unwrap_or(0),
        label: format!("Minecraft {version_id}.jar"),
    });
    if let Some(logging_file) = vanilla_metadata.pointer("/logging/client/file") {
        if let (Some(url), Some(id)) = (logging_file.get("url").and_then(Value::as_str), logging_file.get("id").and_then(Value::as_str)) {
            ensure_mojang_url(url)?;
            downloads.push(DownloadItem {
                url: url.to_string(),
                relative_path: PathBuf::from("assets/log_configs").join(id),
                sha1: logging_file.get("sha1").and_then(Value::as_str).map(ToOwned::to_owned),
                size: logging_file.get("size").and_then(Value::as_u64).unwrap_or(0),
                label: format!("Logging config {id}"),
            });
        }
    }

    let os_name = current_os_name();
    let arch = if cfg!(target_pointer_width = "64") { "64" } else { "32" };
    let mut native_paths = Vec::<PathBuf>::new();
    if let Some(libraries) = metadata.get("libraries").and_then(Value::as_array) {
        for library in libraries {
            if !rules_allow(library.get("rules"), &os_name) { continue; }
            if let Some(artifact) = library.pointer("/downloads/artifact") {
                if let Some(item) = artifact_item(artifact, library.get("name").and_then(Value::as_str).unwrap_or("library"), false)? { downloads.push(item); }
            } else if library.get("downloads").is_none() {
                if let Some(item) = legacy_artifact_item(library)? { downloads.push(item); }
            }

            let native_key = library.pointer(&format!("/natives/{os_name}")).and_then(Value::as_str);
            if let Some(native_pattern) = native_key {
                let classifier = native_pattern.replace("${arch}", arch);
                if let Some(native_artifact) = library.pointer(&format!("/downloads/classifiers/{classifier}")) {
                    if let Some(item) = artifact_item(native_artifact, &format!("native {classifier}"), true)? {
                        native_paths.push(PathBuf::from(&settings.minecraft_dir).join(&item.relative_path));
                        downloads.push(item);
                    }
                }
            }
        }
    }

    download_batch(app.clone(), client.clone(), root.clone(), version_id.to_string(), "Загрузка Minecraft и библиотек Fabric".into(), downloads, cancel.clone()).await?;

    let native_dir = version_dir.join("natives");
    fs::create_dir_all(&native_dir)?;
    for archive in native_paths {
        let target = native_dir.clone();
        tokio::task::spawn_blocking(move || extract_native_archive(&archive, &target)).await??;
    }

    if let Some(asset_index) = vanilla_metadata.get("assetIndex") {
        let index_id = asset_index.get("id").and_then(Value::as_str).unwrap_or(version_id);
        let index_url = json_string(asset_index, "url")?;
        ensure_mojang_url(&index_url)?;
        let index_relative = PathBuf::from(format!("assets/indexes/{index_id}.json"));
        let index_item = DownloadItem {
            url: index_url,
            relative_path: index_relative.clone(),
            sha1: asset_index.get("sha1").and_then(Value::as_str).map(ToOwned::to_owned),
            size: asset_index.get("size").and_then(Value::as_u64).unwrap_or(0),
            label: format!("Asset index {index_id}"),
        };
        download_batch(app.clone(), client.clone(), root.clone(), version_id.to_string(), "Загрузка индекса ресурсов".into(), vec![index_item], cancel.clone()).await?;
        let index_path = root.join(&index_relative);
        let asset_index_json: Value = serde_json::from_slice(&tokio::fs::read(&index_path).await?)
            .context("Повреждён Minecraft asset index")?;
        let mut asset_items = Vec::<DownloadItem>::new();
        if let Some(objects) = asset_index_json.get("objects").and_then(Value::as_object) {
            for (asset_name, object) in objects {
                let hash = object.get("hash").and_then(Value::as_str).unwrap_or_default();
                if hash.len() != 40 || !hash.bytes().all(|c| c.is_ascii_hexdigit()) { continue; }
                let prefix = &hash[0..2];
                asset_items.push(DownloadItem {
                    url: format!("https://resources.download.minecraft.net/{prefix}/{hash}"),
                    relative_path: PathBuf::from(format!("assets/objects/{prefix}/{hash}")),
                    sha1: Some(hash.to_string()),
                    size: object.get("size").and_then(Value::as_u64).unwrap_or(0),
                    label: asset_name.clone(),
                });
            }
        }
        download_batch(app.clone(), client.clone(), root.clone(), version_id.to_string(), "Загрузка игровых ресурсов".into(), asset_items, cancel.clone()).await?;
        if asset_index_json.get("virtual").and_then(Value::as_bool).unwrap_or(false) {
            build_virtual_assets(&root, index_id, &asset_index_json)?;
        }
        if asset_index_json.get("map_to_resources").and_then(Value::as_bool).unwrap_or(false) {
            build_legacy_resources(&root, &asset_index_json)?;
        }
    }

    // Fabric API is a regular Fabric mod and must be present in the instance mods folder.
    let fabric_api_item = DownloadItem {
        url: fabric_api_url,
        relative_path: PathBuf::from("instances").join(version_id).join("mods").join(format!("fabric-api-{fabric_api_version}.jar")),
        sha1: Some(fabric_api_sha1.clone()),
        size: 0,
        label: format!("Fabric API {fabric_api_version}"),
    };
    let current_fabric_api_name = fabric_api_item.relative_path.file_name().map(|name| name.to_string_lossy().to_string());
    download_batch(app.clone(), client.clone(), root.clone(), version_id.to_string(), "Установка Fabric API".into(), vec![fabric_api_item], cancel.clone()).await?;
    // Keep exactly one Fabric API version in the mods directory after the new JAR is verified.
    let mods_dir = root.join("instances").join(version_id).join("mods");
    fs::create_dir_all(&mods_dir)?;
    for entry in fs::read_dir(&mods_dir)? {
        let entry = entry?;
        if !entry.file_type()?.is_file() { continue; }
        let name = entry.file_name().to_string_lossy().to_string();
        if name.starts_with("fabric-api-") && name.ends_with(".jar") && Some(name.clone()) != current_fabric_api_name {
            fs::remove_file(entry.path()).with_context(|| format!("Не удалось удалить старую версию Fabric API: {name}"))?;
        }
    }

    // Java 17 is managed by ZisMine and stored in runtime/ beside the launcher on Windows.
    let runtime_base = runtime_base_dir(&app)?;
    ensure_runtime(app.clone(), client.clone(), &runtime_base, java_major, cancel.clone()).await
        .context("Не удалось установить Java рядом с лаунчером. Проверь, что папка установки доступна для записи.")?;

    settings.auto_java = true;
    settings.java_path.clear();
    settings.selected_version = version_id.to_string();
    write_json(&settings_path, &settings)?;
    // Mark a version as installed only after client, libraries, assets and required runtime are complete.
    let marker = install_marker;
    let marker_tmp = version_dir.join(".zismine-installed.json.part");
    fs::write(&marker_tmp, serde_json::to_vec_pretty(&serde_json::json!({
        "version": SUPPORTED_VERSION,
        "minecraft_version": SUPPORTED_VERSION,
        "loader": "fabric",
        "fabric_loader_version": fabric_loader_version,
        "fabric_api_version": fabric_api_version,
        "fabric_api_sha1": fabric_api_sha1,
        "java_major": java_major,
        "completed": true
    }))?)?;
    if marker.exists() { fs::remove_file(&marker)?; }
    fs::rename(marker_tmp, marker)?;
    Ok(())
}

fn artifact_item(artifact: &Value, label: &str, _native: bool) -> Result<Option<DownloadItem>> {
    let Some(url) = artifact.get("url").and_then(Value::as_str) else { return Ok(None); };
    let Some(path) = artifact.get("path").and_then(Value::as_str) else { return Ok(None); };
    ensure_mojang_url(url)?;
    let relative = PathBuf::from("libraries").join(path);
    if relative.components().any(|c| matches!(c, Component::ParentDir | Component::RootDir | Component::Prefix(_))) { bail!("Некорректный путь библиотеки."); }
    Ok(Some(DownloadItem {
        url: url.to_string(), relative_path: relative,
        sha1: artifact.get("sha1").and_then(Value::as_str).map(ToOwned::to_owned),
        size: artifact.get("size").and_then(Value::as_u64).unwrap_or(0),
        label: label.to_string(),
    }))
}

fn legacy_artifact_item(library: &Value) -> Result<Option<DownloadItem>> {
    let Some(name) = library.get("name").and_then(Value::as_str) else { return Ok(None); };
    let parts: Vec<&str> = name.split(':').collect();
    if parts.len() < 3 { return Ok(None); }
    let group_path = parts[0].replace('.', "/");
    let artifact = parts[1];
    let version = parts[2];
    let classifier = parts.get(3).map(|s| format!("-{s}")).unwrap_or_default();
    let filename = format!("{artifact}-{version}{classifier}.jar");
    let path = format!("{group_path}/{artifact}/{version}/{filename}");
    let base = library.get("url").and_then(Value::as_str).unwrap_or("https://libraries.minecraft.net/");
    let base = if base.ends_with('/') { base.to_string() } else { format!("{base}/") };
    let url = format!("{base}{path}");
    ensure_mojang_url(&url)?;
    Ok(Some(DownloadItem { url, relative_path: PathBuf::from("libraries").join(path), sha1: None, size: 0, label: name.to_string() }))
}

fn json_string(value: &Value, key: &str) -> Result<String> {
    value.get(key).and_then(Value::as_str).map(ToOwned::to_owned)
        .with_context(|| format!("В метаданных отсутствует поле {key}"))
}

fn validate_version_id(id: &str) -> Result<()> {
    if id.is_empty() || id.len() > 64 || !id.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'.' || b == b'_' || b == b'-') {
        bail!("Недопустимый идентификатор версии Minecraft.");
    }
    Ok(())
}

fn current_os_name() -> &'static str {
    if cfg!(target_os = "windows") { "windows" }
    else if cfg!(target_os = "macos") { "osx" }
    else { "linux" }
}

fn rules_allow(rules: Option<&Value>, os_name: &str) -> bool {
    let Some(list) = rules.and_then(Value::as_array) else { return true; };
    let mut allowed = false;
    for rule in list {
        let mut matches = true;
        if let Some(os) = rule.get("os") {
            if let Some(name) = os.get("name").and_then(Value::as_str) { matches &= name == os_name; }
            if let Some(arch) = os.get("arch").and_then(Value::as_str) {
                if arch == "x86" { matches &= cfg!(target_pointer_width = "32"); }
                if arch == "x86_64" { matches &= cfg!(target_pointer_width = "64"); }
            }
        }
        if let Some(features) = rule.get("features").and_then(Value::as_object) {
            for (_feature, value) in features {
                if value.as_bool() == Some(true) { matches = false; }
            }
        }
        if matches {
            allowed = rule.get("action").and_then(Value::as_str) == Some("allow");
        }
    }
    allowed
}

fn extract_native_archive(archive_path: &Path, destination: &Path) -> Result<()> {
    let file = fs::File::open(archive_path).with_context(|| format!("Не удалось открыть native archive {}", archive_path.display()))?;
    let mut archive = ZipArchive::new(file).context("Повреждён native archive")?;
    for index in 0..archive.len() {
        let mut entry = archive.by_index(index)?;
        let Some(enclosed) = entry.enclosed_name() else { continue; };
        if enclosed.components().any(|c| matches!(c, Component::ParentDir | Component::RootDir | Component::Prefix(_))) { continue; }
        if enclosed.to_string_lossy().starts_with("META-INF/") || entry.is_dir() { continue; }
        let output_path = destination.join(enclosed);
        if let Some(parent) = output_path.parent() { fs::create_dir_all(parent)?; }
        let mut output = fs::File::create(output_path)?;
        std::io::copy(&mut entry, &mut output)?;
    }
    Ok(())
}

fn build_virtual_assets(root: &Path, index_id: &str, index: &Value) -> Result<()> {
    let index_component = Path::new(index_id);
    if index_component.components().count() != 1 || !index_component.components().all(|part| matches!(part, Component::Normal(_))) {
        bail!("Asset index содержит небезопасный ID.");
    }
    let objects = index.get("objects").and_then(Value::as_object);
    let Some(objects) = objects else { return Ok(()); };
    for (name, object) in objects {
        let relative_name = Path::new(name);
        if relative_name.as_os_str().is_empty() || !relative_name.components().all(|part| matches!(part, Component::Normal(_))) {
            bail!("Asset index содержит небезопасное имя ресурса.");
        }
        let hash = object.get("hash").and_then(Value::as_str).unwrap_or_default();
        if hash.len() != 40 || !hash.bytes().all(|b| b.is_ascii_hexdigit()) { continue; }
        let source = root.join("assets/objects").join(&hash[0..2]).join(hash);
        let target = root.join("assets/virtual").join(index_id).join(relative_name);
        if target.exists() { continue; }
        if let Some(parent) = target.parent() { fs::create_dir_all(parent)?; }
        if source.exists() { fs::copy(source, target)?; }
    }
    Ok(())
}

fn build_legacy_resources(root: &Path, index: &Value) -> Result<()> {
    let objects = index.get("objects").and_then(Value::as_object);
    let Some(objects) = objects else { return Ok(()); };
    for (name, object) in objects {
        let relative_name = Path::new(name);
        if relative_name.as_os_str().is_empty() || !relative_name.components().all(|part| matches!(part, Component::Normal(_))) {
            bail!("Asset index содержит небезопасное имя ресурса.");
        }
        let hash = object.get("hash").and_then(Value::as_str).unwrap_or_default();
        if hash.len() != 40 || !hash.bytes().all(|b| b.is_ascii_hexdigit()) { continue; }
        let source = root.join("assets/objects").join(&hash[0..2]).join(hash);
        let target = root.join("resources").join(relative_name);
        if target.exists() { continue; }
        if let Some(parent) = target.parent() { fs::create_dir_all(parent)?; }
        if source.exists() { fs::copy(source, target)?; }
    }
    Ok(())
}

#[cfg(test)]
mod fabric_tests {
    use super::*;

    #[test]
    fn fabric_profile_merges_loader_libraries_and_launch_arguments() {
        let vanilla = serde_json::json!({
            "id":"1.20.1", "mainClass":"net.minecraft.client.main.Main",
            "libraries":[{"name":"com.mojang:logging:1.0"}],
            "arguments":{"game":["--username", "${auth_player_name}"], "jvm":["-XstartOnFirstThread"]}
        });
        let fabric = serde_json::json!({
            "inheritsFrom":"1.20.1", "mainClass":"net.fabricmc.loader.impl.launch.knot.KnotClient",
            "libraries":[{"name":"net.fabricmc:fabric-loader:0.16.0"}],
            "arguments":{"game":["--fabric"], "jvm":["-Dfabric.test=true"]}
        });
        let merged = merge_fabric_profile(vanilla, fabric).unwrap();
        assert_eq!(merged["mainClass"], "net.fabricmc.loader.impl.launch.knot.KnotClient");
        assert_eq!(merged["libraries"].as_array().unwrap().len(), 2);
        assert!(merged.pointer("/arguments/game").unwrap().as_array().unwrap().contains(&Value::String("--fabric".into())));
        assert!(merged.pointer("/arguments/jvm").unwrap().as_array().unwrap().contains(&Value::String("-Dfabric.test=true".into())));
    }

    #[test]
    fn fabric_api_maven_version_filter_is_exact_to_minecraft_1_20_1() {
        let xml = "<versioning><versions><version>0.92.2+1.20.1</version><version>0.100.0+1.21.1</version><version>0.92.3+1.20.1</version></versions></versioning>";
        let compatible = xml.split("<version>").skip(1).filter_map(|c| c.split("</version>").next()).filter(|v| v.ends_with("+1.20.1")).collect::<Vec<_>>();
        assert_eq!(compatible.last(), Some(&"0.92.3+1.20.1"));
    }
}
