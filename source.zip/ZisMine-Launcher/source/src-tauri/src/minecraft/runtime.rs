use anyhow::{bail, Context, Result};
use serde_json::Value;
use sha1::Digest;
use std::{fs, path::{Component, Path, PathBuf}};
use tauri::AppHandle;
use tokio_util::sync::CancellationToken;

use super::{download::{download_batch, DownloadItem}, manifest::ensure_mojang_url};

const RUNTIME_INDEX_URL: &str = "https://piston-meta.mojang.com/v1/products/java-runtime/2ec0cc96c44e5a76b9c8b7c39df7210883d12871/all.json";
const COMPONENT_ORDER: [&str; 6] = ["jre-legacy", "java-runtime-alpha", "java-runtime-beta", "java-runtime-gamma", "java-runtime-delta", "java-runtime-epsilon"];

#[derive(Debug, Clone)]
pub struct InstalledRuntime {
    pub java_path: PathBuf,
    pub component: String,
    pub major: u32,
}

pub async fn ensure_runtime(app: AppHandle, client: reqwest::Client, root: &Path, major: u32, cancel: CancellationToken) -> Result<InstalledRuntime> {
    let platform = platform_key()?;
    let index: Value = client.get(RUNTIME_INDEX_URL).send().await
        .context("Не удалось загрузить официальный Mojang Java Runtime index")?
        .error_for_status().context("Mojang Java Runtime index вернул HTTP-ошибку")?
        .json().await.context("Не удалось разобрать Mojang Java Runtime index")?;
    let platform_data = index.get(&platform).context("Для этой платформы нет Mojang Java Runtime")?;

    let mut selected: Option<(String, Value)> = None;
    for component in COMPONENT_ORDER {
        let Some(entries) = platform_data.get(component).and_then(Value::as_array) else { continue; };
        for entry in entries {
            let runtime_version = entry.pointer("/version/name").and_then(Value::as_str).unwrap_or_default();
            if parse_runtime_major(runtime_version) == Some(major) {
                selected = Some((component.to_string(), entry.clone()));
            }
        }
        if selected.is_some() { break; }
    }
    let (component, selected_entry) = selected.with_context(|| format!("Mojang не опубликовала Runtime Java {major} для {platform}. Укажи совместимую системную Java в настройках."))?;
    let manifest_url = selected_entry.pointer("/manifest/url").and_then(Value::as_str).context("В runtime index отсутствует URL manifest")?;
    let manifest_sha1 = selected_entry.pointer("/manifest/sha1").and_then(Value::as_str).context("В runtime index отсутствует SHA-1 manifest")?;
    ensure_mojang_url(manifest_url)?;
    let manifest_bytes = client.get(manifest_url).send().await.context("Не удалось запросить Java Runtime manifest")?
        .error_for_status().context("Java Runtime manifest вернул HTTP-ошибку")?
        .bytes().await.context("Не удалось прочитать Java Runtime manifest")?;
    let actual_manifest_hash = format!("{:x}", sha1::Sha1::digest(&manifest_bytes));
    if !actual_manifest_hash.eq_ignore_ascii_case(manifest_sha1) { bail!("SHA-1 Java Runtime manifest не совпадает с индексом Mojang."); }
    let manifest: Value = serde_json::from_slice(&manifest_bytes).context("Java Runtime manifest повреждён")?;
    let runtime_root = root.join("runtime").join(&component).join(&platform);
    fs::create_dir_all(&runtime_root).with_context(|| format!(
        "Не удалось создать папку Java рядом с лаунчером: {}", runtime_root.display()
    ))?;
    let stamp_path = runtime_root.join(".zismine-runtime.json");
    // Do not trust a marker alone: download_batch hashes the complete runtime manifest and repairs altered files.

    let files = manifest.get("files").and_then(Value::as_object).context("В Java Runtime manifest отсутствует files map")?;
    let mut downloads = Vec::new();
    let mut directories = Vec::new();
    let mut links = Vec::new();
    let mut executable_files = Vec::new();
    for (relative_name, entry) in files {
        let relative = PathBuf::from(relative_name);
        if !is_safe_relative(&relative) { bail!("Runtime manifest содержит небезопасный путь: {relative_name}"); }
        match entry.get("type").and_then(Value::as_str).unwrap_or("file") {
            "directory" => directories.push(relative),
            "link" => {
                if let Some(target) = entry.get("target").and_then(Value::as_str) {
                    let target_path = PathBuf::from(target);
                    if resolve_link_target(&runtime_root, &relative, &target_path).is_some() {
                        links.push((relative, target_path));
                    }
                }
            }
            _ => {
                let Some(raw) = entry.pointer("/downloads/raw") else { continue; };
                let Some(url) = raw.get("url").and_then(Value::as_str) else { continue; };
                ensure_mojang_url(url)?;
                if entry.get("executable").and_then(Value::as_bool).unwrap_or(false) { executable_files.push(relative.clone()); }
                downloads.push(DownloadItem {
                    url: url.to_string(),
                    relative_path: PathBuf::from("runtime").join(&component).join(&platform).join(&relative),
                    sha1: raw.get("sha1").and_then(Value::as_str).map(ToOwned::to_owned),
                    size: raw.get("size").and_then(Value::as_u64).unwrap_or(0),
                    label: format!("Java {major}: {relative_name}"),
                });
            }
        }
    }
    for directory in directories { tokio::fs::create_dir_all(runtime_root.join(directory)).await?; }
    download_batch(app, client, root.to_path_buf(), format!("Java {major}"), format!("Установка Java {major}"), downloads, cancel).await?;

    for (link, target) in links {
        let link_path = runtime_root.join(&link);
        let Some(resolved_target) = resolve_link_target(&runtime_root, &link, &target) else { continue; };
        if link_path.exists() || !resolved_target.exists() { continue; }
        if let Some(parent) = link_path.parent() { fs::create_dir_all(parent)?; }
        #[cfg(unix)] { let _ = std::os::unix::fs::symlink(&target, &link_path); }
        #[cfg(windows)] {
            let created = if resolved_target.is_dir() {
                std::os::windows::fs::symlink_dir(&target, &link_path)
            } else {
                std::os::windows::fs::symlink_file(&target, &link_path)
            };
            if created.is_err() {
                if resolved_target.is_dir() { let _ = fs::create_dir_all(&link_path); }
                else { let _ = fs::copy(&resolved_target, &link_path); }
            }
        }
    }
    #[cfg(unix)] {
        use std::os::unix::fs::PermissionsExt;
        for path in executable_files {
            let path = runtime_root.join(path);
            if let Ok(metadata) = fs::metadata(&path) {
                let mut permissions = metadata.permissions();
                permissions.set_mode(permissions.mode() | 0o111);
                let _ = fs::set_permissions(path, permissions);
            }
        }
    }
    let java = find_java_binary(&runtime_root).context("Java Runtime скачан, но исполняемый файл bin/java не найден.")?;
    fs::write(stamp_path, serde_json::to_vec_pretty(&serde_json::json!({
        "manifest_sha1": manifest_sha1,
        "major": major,
        "component": component.clone(),
        "platform": platform.clone(),
    }))?)?;
    Ok(InstalledRuntime { java_path: java, component, major })
}

pub fn preferred_launch_java(java_path: &Path) -> PathBuf {
    #[cfg(target_os = "windows")]
    {
        if java_path.file_name().and_then(|name| name.to_str()).is_some_and(|name| name.eq_ignore_ascii_case("java.exe")) {
            if let Some(parent) = java_path.parent() {
                let javaw = parent.join("javaw.exe");
                if javaw.is_file() { return javaw; }
            }
        }
    }
    java_path.to_path_buf()
}

pub fn installed_java_path(root: &Path, major: u32) -> Option<PathBuf> {
    let platform = platform_key().ok()?;
    for component in COMPONENT_ORDER {
        let path = root.join("runtime").join(component).join(&platform);
        let Some(java) = find_java_binary(&path) else { continue; };
        let marker = path.join(".zismine-runtime.json");
        let Ok(bytes) = fs::read(marker) else { continue; };
        let Ok(stamp) = serde_json::from_slice::<Value>(&bytes) else { continue; };
        if stamp.get("major").and_then(Value::as_u64) == Some(major as u64) {
            return Some(java);
        }
    }
    None
}

fn platform_key() -> Result<String> {
    #[cfg(all(target_os = "windows", target_arch = "x86_64"))] { return Ok("windows-x64".into()); }
    #[cfg(all(target_os = "windows", target_arch = "aarch64"))] { return Ok("windows-arm64".into()); }
    #[cfg(all(target_os = "windows", target_arch = "x86"))] { return Ok("windows-x86".into()); }
    #[cfg(all(target_os = "macos", target_arch = "x86_64"))] { return Ok("mac-os".into()); }
    #[cfg(all(target_os = "macos", target_arch = "aarch64"))] { return Ok("mac-os-arm64".into()); }
    #[cfg(all(target_os = "linux", target_arch = "x86_64"))] { return Ok("linux".into()); }
    #[cfg(all(target_os = "linux", target_arch = "aarch64"))] { return Ok("linux-arm64".into()); }
    #[cfg(not(any(
        all(target_os = "windows", target_arch = "x86_64"),
        all(target_os = "windows", target_arch = "aarch64"),
        all(target_os = "windows", target_arch = "x86"),
        all(target_os = "macos", target_arch = "x86_64"),
        all(target_os = "macos", target_arch = "aarch64"),
        all(target_os = "linux", target_arch = "x86_64"),
        all(target_os = "linux", target_arch = "aarch64")
    )))] {
        bail!("Платформа/архитектура не поддерживается Mojang Runtime manifest.")
    }
}

fn find_java_binary(root: &Path) -> Option<PathBuf> {
    #[cfg(target_os = "windows")]
    let candidates = [root.join("bin/java.exe"), root.join("bin/javaw.exe")];
    #[cfg(target_os = "macos")]
    let candidates = [root.join("Contents/Home/bin/java"), root.join("jre.bundle/Contents/Home/bin/java"), root.join("bin/java")];
    #[cfg(target_os = "linux")]
    let candidates = [root.join("bin/java"), root.join("jre/bin/java")];
    candidates.into_iter().find(|path| path.is_file())
}

fn parse_runtime_major(version: &str) -> Option<u32> {
    if version.starts_with("1.") { return version.split('.').nth(1)?.parse().ok(); }
    let major: String = version.chars().take_while(|c| c.is_ascii_digit()).collect();
    major.parse().ok()
}

fn is_safe_relative(path: &Path) -> bool {
    !path.as_os_str().is_empty() && path.components().all(|component| matches!(component, Component::Normal(_)))
}

fn resolve_link_target(root: &Path, link: &Path, target: &Path) -> Option<PathBuf> {
    if target.is_absolute() || target.components().any(|part| matches!(part, Component::RootDir | Component::Prefix(_))) {
        return None;
    }
    let mut parts = link.parent()?.components().filter_map(|part| match part {
        Component::Normal(value) => Some(value.to_os_string()),
        _ => None,
    }).collect::<Vec<_>>();
    for part in target.components() {
        match part {
            Component::Normal(value) => parts.push(value.to_os_string()),
            Component::CurDir => {},
            Component::ParentDir => { parts.pop()?; },
            Component::RootDir | Component::Prefix(_) => return None,
        }
    }
    let resolved = parts.into_iter().fold(root.to_path_buf(), |path, part| path.join(part));
    Some(resolved)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn parses_java_runtime_majors() {
        assert_eq!(parse_runtime_major("8u202"), Some(8));
        assert_eq!(parse_runtime_major("21.0.7"), Some(21));
        assert_eq!(parse_runtime_major("25.0.1"), Some(25));
    }
    #[test]
    fn rejects_runtime_path_traversal() {
        assert!(!is_safe_relative(Path::new("../../evil")));
        assert!(is_safe_relative(Path::new("bin/java")));
    }
    #[test]
    fn runtime_links_can_use_safe_parent_segments_without_escaping_root() {
        let root = Path::new("/tmp/runtime");
        assert_eq!(resolve_link_target(root, Path::new("lib/server/libjvm.so"), Path::new("../client/libjvm.so")), Some(root.join("lib/client/libjvm.so")));
        assert_eq!(resolve_link_target(root, Path::new("bin/java"), Path::new("../../../../etc/passwd")), None);
    }
    #[test]
    fn installed_runtime_marker_must_match_requested_major() {
        let marker: Value = serde_json::json!({"major": 21, "manifest_sha1": "abc"});
        assert_eq!(marker.get("major").and_then(Value::as_u64), Some(21));
    }
}
