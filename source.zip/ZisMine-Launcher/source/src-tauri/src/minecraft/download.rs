use anyhow::{bail, Context, Result};
use futures_util::{stream, StreamExt, TryStreamExt};
use reqwest::Client;
use serde::Serialize;
use sha1::{Digest, Sha1};
use std::{path::{Component, Path, PathBuf}, sync::{Arc, atomic::{AtomicU64, AtomicUsize, Ordering}}, time::Instant};
use tauri::{AppHandle, Emitter};
use tokio::{fs, io::AsyncWriteExt};
use tokio_util::sync::CancellationToken;

use super::manifest::ensure_mojang_url;

#[derive(Debug, Clone)]
pub struct DownloadItem {
    pub url: String,
    pub relative_path: PathBuf,
    pub sha1: Option<String>,
    pub size: u64,
    pub label: String,
}

#[derive(Debug, Clone, Serialize)]
pub struct DownloadProgress {
    pub version: String,
    pub completed: usize,
    pub total: usize,
    pub current_file: String,
    pub phase: String,
    pub downloaded_bytes: u64,
    pub total_bytes: u64,
    pub speed_bytes_sec: u64,
}

pub async fn download_batch(
    app: AppHandle,
    client: Client,
    root: PathBuf,
    version: String,
    phase: String,
    items: Vec<DownloadItem>,
    cancel: CancellationToken,
) -> Result<()> {
    if items.is_empty() { return Ok(()); }
    let total = items.len();
    let total_bytes = items.iter().map(|item| item.size).sum::<u64>();
    let completed = Arc::new(AtomicUsize::new(0));
    let downloaded = Arc::new(AtomicU64::new(0));
    let started = Instant::now();
    let app_for_tasks = app.clone();
    let version_for_tasks = version.clone();
    let phase_for_tasks = phase.clone();
    let root_for_tasks = root.clone();

    let tasks = stream::iter(items.into_iter().map(|item| {
        let client = client.clone();
        let completed = completed.clone();
        let downloaded = downloaded.clone();
        let app = app_for_tasks.clone();
        let version = version_for_tasks.clone();
        let phase = phase_for_tasks.clone();
        let root = root_for_tasks.clone();
        let cancel = cancel.clone();
        async move {
            if cancel.is_cancelled() { bail!("Загрузка отменена пользователем."); }
            let path = safe_join(&root, &item.relative_path)?;
            if verify_existing(&path, item.sha1.as_deref(), item.size).await {
                completed.fetch_add(1, Ordering::Relaxed);
                downloaded.fetch_add(item.size, Ordering::Relaxed);
                emit_progress(&app, &version, &phase, &item.label, completed.load(Ordering::Relaxed), total, downloaded.load(Ordering::Relaxed), total_bytes, started);
                return Ok::<(), anyhow::Error>(());
            }
            let mut last_error = None;
            let file_bytes = Arc::new(AtomicU64::new(0));
            for attempt in 0..3 {
                file_bytes.store(0, Ordering::Relaxed);
                if cancel.is_cancelled() { bail!("Загрузка отменена пользователем."); }
                match download_one(&client, &item, &path, &downloaded, &app, &version, &phase, total, completed.load(Ordering::Relaxed), total_bytes, started, &cancel, &file_bytes).await {
                    Ok(()) => { last_error = None; break; }
                    Err(error) => {
                        downloaded.fetch_sub(file_bytes.swap(0, Ordering::Relaxed), Ordering::Relaxed);
                        if cancel.is_cancelled() { return Err(error); }
                        last_error = Some(error);
                        let _ = fs::remove_file(path.with_extension("part")).await;
                        if attempt < 2 { tokio::time::sleep(std::time::Duration::from_millis(650 * (attempt + 1))).await; }
                    }
                }
            }
            if let Some(error) = last_error { return Err(error).with_context(|| format!("Не удалось скачать {} после 3 попыток", item.label)); }
            completed.fetch_add(1, Ordering::Relaxed);
            emit_progress(&app, &version, &phase, &item.label, completed.load(Ordering::Relaxed), total, downloaded.load(Ordering::Relaxed), total_bytes, started);
            Ok(())
        }
    })).buffer_unordered(6).try_collect::<Vec<_>>();
    tasks.await?;
    Ok(())
}

async fn download_one(
    client: &Client, item: &DownloadItem, destination: &Path, downloaded: &AtomicU64,
    app: &AppHandle, version: &str, phase: &str, total: usize, completed: usize,
    total_bytes: u64, started: Instant, cancel: &CancellationToken, file_bytes_total: &AtomicU64,
) -> Result<()> {
    ensure_mojang_url(&item.url)?;
    if let Some(parent) = destination.parent() { fs::create_dir_all(parent).await?; }
    let temporary = destination.with_extension("part");
    let mut response = tokio::select! {
        _ = cancel.cancelled() => bail!("Загрузка отменена пользователем."),
        result = client.get(&item.url).send() => result.context("Ошибка HTTP при загрузке файла")?.error_for_status().context("Сервер вернул ошибку загрузки файла")?,
    };
    let mut file = fs::File::create(&temporary).await.context("Не удалось создать временный файл загрузки")?;
    let mut hasher = Sha1::new();
    let mut file_bytes = 0u64;
    loop {
        let next_chunk = tokio::select! {
            _ = cancel.cancelled() => bail!("Загрузка отменена пользователем."),
            chunk = response.chunk() => chunk.context("Соединение прервалось во время загрузки")?,
        };
        let Some(chunk) = next_chunk else { break; };
        file.write_all(&chunk).await.context("Не удалось записать скачанный файл")?;
        hasher.update(&chunk);
        file_bytes += chunk.len() as u64;
        downloaded.fetch_add(chunk.len() as u64, Ordering::Relaxed);
        file_bytes_total.fetch_add(chunk.len() as u64, Ordering::Relaxed);
        if file_bytes % (1024 * 1024) < chunk.len() as u64 {
            emit_progress(app, version, phase, &item.label, completed, total, downloaded.load(Ordering::Relaxed), total_bytes, started);
        }
    }
    file.flush().await?;
    drop(file);
    if item.size > 0 && file_bytes != item.size {
        bail!("Размер файла не совпал: ожидалось {} байт, получено {file_bytes}", item.size);
    }
    let actual = hex::encode(hasher.finalize());
    if let Some(expected) = item.sha1.as_deref() {
        if !actual.eq_ignore_ascii_case(expected) { bail!("SHA-1 не совпал для {}", item.label); }
    }
    if fs::metadata(destination).await.is_ok() { fs::remove_file(destination).await?; }
    fs::rename(&temporary, destination).await.context("Не удалось установить скачанный файл")?;
    Ok(())
}

async fn verify_existing(path: &Path, expected_sha1: Option<&str>, expected_size: u64) -> bool {
    let metadata = match fs::metadata(path).await { Ok(m) => m, Err(_) => return false };
    if expected_size > 0 && metadata.len() != expected_size { return false; }
    if let Some(expected) = expected_sha1 {
        match hash_file(path).await { Ok(hash) => hash.eq_ignore_ascii_case(expected), Err(_) => false }
    } else { true }
}

pub async fn hash_file(path: &Path) -> Result<String> {
    use tokio::io::AsyncReadExt;
    let mut file = fs::File::open(path).await?;
    let mut hasher = Sha1::new();
    let mut buffer = vec![0u8; 256 * 1024];
    loop {
        let read = file.read(&mut buffer).await?;
        if read == 0 { break; }
        hasher.update(&buffer[..read]);
    }
    Ok(hex::encode(hasher.finalize()))
}

fn safe_join(root: &Path, relative: &Path) -> Result<PathBuf> {
    if relative.components().any(|c| matches!(c, Component::ParentDir | Component::RootDir | Component::Prefix(_))) {
        bail!("Путь загрузки содержит недопустимые сегменты.");
    }
    Ok(root.join(relative))
}

fn emit_progress(app: &AppHandle, version: &str, phase: &str, current_file: &str, completed: usize, total: usize, downloaded_bytes: u64, total_bytes: u64, started: Instant) {
    let elapsed = started.elapsed().as_secs_f64().max(0.1);
    let payload = DownloadProgress {
        version: version.to_string(), completed, total, current_file: current_file.to_string(), phase: phase.to_string(),
        downloaded_bytes, total_bytes, speed_bytes_sec: (downloaded_bytes as f64 / elapsed) as u64,
    };
    let _ = app.emit("download-progress", payload);
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn safe_join_rejects_parent_traversal() {
        assert!(safe_join(Path::new("/tmp/root"), Path::new("../escape")).is_err());
        assert!(safe_join(Path::new("/tmp/root"), Path::new("libraries/org/example.jar")).is_ok());
    }
    #[tokio::test]
    async fn sha1_is_computed_for_file() {
        let dir = tempfile::tempdir().unwrap();
        let file = dir.path().join("test.bin");
        fs::write(&file, b"abc").await.unwrap();
        assert_eq!(hash_file(&file).await.unwrap(), "a9993e364706816aba3e25717850c26c9cd0d89d");
    }
}
