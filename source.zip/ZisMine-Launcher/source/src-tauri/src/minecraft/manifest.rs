use anyhow::{Context, Result};
use serde::{Deserialize, Serialize};
use serde_json::Value;
use sha1::Digest;

pub const MANIFEST_URL: &str = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json";

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ManifestVersion {
    pub id: String,
    #[serde(rename = "type")]
    pub version_type: String,
    pub url: String,
    #[serde(rename = "releaseTime", default)]
    pub release_time: String,
    #[serde(default)]
    pub sha1: Option<String>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct VersionManifest {
    pub latest: LatestVersions,
    pub versions: Vec<ManifestVersion>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct LatestVersions {
    pub release: String,
    pub snapshot: String,
}

pub async fn fetch_manifest(client: &reqwest::Client) -> Result<VersionManifest> {
    client.get(MANIFEST_URL).send().await
        .context("Не удалось загрузить официальный Minecraft Version Manifest")?
        .error_for_status().context("Mojang Version Manifest вернул ошибку HTTP")?
        .json::<VersionManifest>().await.context("Не удалось разобрать Minecraft Version Manifest")
}

pub async fn fetch_version_json(client: &reqwest::Client, url: &str, expected_sha1: Option<&str>) -> Result<Value> {
    ensure_mojang_url(url)?;
    let bytes = client.get(url).send().await.context("Не удалось запросить метаданные версии")?
        .error_for_status().context("Сервер метаданных версии вернул ошибку HTTP")?
        .bytes().await.context("Не удалось прочитать JSON метаданных версии")?;
    if let Some(hash) = expected_sha1 {
        let actual = format!("{:x}", sha1::Sha1::digest(&bytes));
        if !actual.eq_ignore_ascii_case(hash) { anyhow::bail!("SHA-1 метаданных версии не совпадает с Version Manifest."); }
    }
    serde_json::from_slice(&bytes).context("JSON метаданных версии Minecraft повреждён")
}


/// Returns the Java runtime required by the pinned Minecraft 1.20.1 client.
/// Mojang's version JSON remains authoritative; 17 is only a safe fallback
/// for the pinned release when the optional field is absent.
pub fn required_java_major(metadata: &Value, version_id: &str) -> Result<u32> {
    if version_id != "1.20.1" {
        anyhow::bail!("Поддерживается только Minecraft 1.20.1 Fabric.");
    }
    let declared = metadata.pointer("/javaVersion/majorVersion").and_then(Value::as_u64)
        .and_then(|value| u32::try_from(value).ok());
    let required = declared.unwrap_or(17);
    if required != 17 {
        anyhow::bail!("Minecraft 1.20.1 требует Java 17, но Mojang указала Java {required}.");
    }
    Ok(required)
}

pub fn ensure_mojang_url(url: &str) -> Result<()> {
    let parsed = reqwest::Url::parse(url).context("Некорректный URL в метаданных Mojang")?;
    let host = parsed.host_str().unwrap_or_default();
    let allowed = [
        "piston-meta.mojang.com", "piston-data.mojang.com", "launcher.mojang.com",
        "launchermeta.mojang.com", "libraries.minecraft.net", "resources.download.minecraft.net",
        "maven.fabricmc.net",
    ];
    if parsed.scheme() != "https" || !allowed.iter().any(|h| host == *h || host.ends_with(&format!(".{h}"))) {
        anyhow::bail!("Заблокирован внешний или небезопасный URL из игровых метаданных: {host}");
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn manifest_json_is_parsed() {
        let raw = r#"{"latest":{"release":"1.20.1","snapshot":"1.21-snapshot"},"versions":[{"id":"1.20.1","type":"release","url":"https://piston-meta.mojang.com/test.json","releaseTime":"2023-06-12T13:25:51+00:00"}]}"#;
        let manifest: VersionManifest = serde_json::from_str(raw).unwrap();
        assert_eq!(manifest.latest.release, "1.20.1");
        assert_eq!(manifest.versions[0].version_type, "release");
    }
    #[test]
    fn reads_java_major_with_json_pointer_syntax() {
        let metadata = serde_json::json!({"javaVersion": {"component": "java-runtime-gamma", "majorVersion": 17}});
        assert_eq!(required_java_major(&metadata, "1.20.1").unwrap(), 17);
        let invalid_dotted_path = ["javaVersion", "majorVersion"].join(".");
        assert_eq!(metadata.pointer(&invalid_dotted_path), None);
    }

    #[test]
    fn supported_release_uses_java_17_and_rejects_mismatch() {
        let metadata = serde_json::json!({"id": "1.20.1"});
        assert_eq!(required_java_major(&metadata, "1.20.1").unwrap(), 17);
        let mismatch = serde_json::json!({"javaVersion": {"majorVersion": 21}});
        assert!(required_java_major(&mismatch, "1.20.1").is_err());
        assert!(required_java_major(&metadata, "another-release").is_err());
    }

    #[test]
    fn rejects_non_mojang_hosts() {
        assert!(ensure_mojang_url("http://piston-meta.mojang.com/a").is_err());
        assert!(ensure_mojang_url("https://example.com/a").is_err());
        assert!(ensure_mojang_url("https://libraries.minecraft.net/a").is_ok());
    }
}
