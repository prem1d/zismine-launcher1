use sha1::Digest;
use anyhow::{bail, Context, Result};
use serde_json::Value;
use std::{collections::HashMap, path::{Path, PathBuf}, process::Stdio};
use tauri::{AppHandle, Emitter};
use tokio::{io::{AsyncBufReadExt, AsyncWriteExt, BufReader}, process::Command};

use super::{manifest::required_java_major, runtime::{ensure_runtime, preferred_launch_java}};
use tokio_util::sync::CancellationToken;
use crate::{accounts::{AccountStore, ProfileKind}, auth, settings::Settings, storage::{app_data_dir, read_json, runtime_base_dir}};

pub async fn launch_game(app: AppHandle, client: reqwest::Client, version_id: &str, cancel: CancellationToken) -> Result<(u32, String)> {
    if version_id != "1.20.1" { bail!("Поддерживается только Minecraft 1.20.1 Fabric."); }
    let app_dir = app_data_dir(&app)?;
    let settings: Settings = read_json(&app_dir.join("settings.json")).unwrap_or_default();
    let accounts: AccountStore = read_json(&app_dir.join("accounts.json")).unwrap_or_default();
    let active_id = accounts.active_profile_id.context("Сначала создай или выбери игровой профиль.")?;
    let profile = accounts.profiles.iter().find(|p| p.id == active_id).context("Активный профиль не найден.")?;
    if profile.kind == ProfileKind::Microsoft && settings.oauth_client_id.trim().is_empty() {
        bail!("Для Microsoft-аккаунта нужно указать OAuth Client ID в настройках.");
    }

    let root = PathBuf::from(&settings.minecraft_dir);
    let version_dir = root.join("versions").join(version_id);
    let metadata_path = version_dir.join(format!("{version_id}.json"));
    let install_marker = version_dir.join(".zismine-installed.json");
    let client_jar = version_dir.join(format!("{version_id}.jar"));
    if !client_jar.is_file() || !metadata_path.is_file() || !install_marker.is_file() {
        bail!("Minecraft {version_id} установлена не полностью. Нажми «Проверить» или «Играть», чтобы выполнить восстановление.");
    }
    let metadata: Value = read_json(&metadata_path).context("Не удалось прочитать метаданные установленной версии")?;
    let marker: Value = read_json(&install_marker).context("Не удалось прочитать маркер Fabric установки")?;
    let api_version = marker.get("fabric_api_version").and_then(Value::as_str).context("В маркере установки отсутствует версия Fabric API")?;
    let api_hash = marker.get("fabric_api_sha1").and_then(Value::as_str).context("В маркере установки отсутствует SHA-1 Fabric API")?;
    let api_path = root.join("instances").join(version_id).join("mods").join(format!("fabric-api-{api_version}.jar"));
    let api_bytes = tokio::fs::read(&api_path).await.context("Fabric API не найден. Повтори установку профиля.")?;
    let actual_api_hash = format!("{:x}", sha1::Sha1::digest(&api_bytes));
    if !actual_api_hash.eq_ignore_ascii_case(api_hash) { bail!("Fabric API повреждён. Повтори установку профиля для восстановления."); }
    let required_java = required_java_major(&metadata, version_id)?;
    let runtime_base = runtime_base_dir(&app)?;
    // Reconcile the full Mojang runtime manifest on every launch. Valid files are
    // reused by SHA-1; missing or modified runtime files are downloaded again.
    let installed_runtime = ensure_runtime(app.clone(), client.clone(), &runtime_base, required_java, cancel).await
        .context("Не удалось проверить или восстановить Java рядом с лаунчером. Проверь, что папка установки доступна для записи.")?;
    validate_java_binary(&installed_runtime.java_path, required_java).await?;
    let java_path = installed_runtime.java_path;

    let game_dir = root.join("instances").join(version_id);
    tokio::fs::create_dir_all(&game_dir).await?;
    let natives_dir = version_dir.join("natives");
    tokio::fs::create_dir_all(&natives_dir).await?;

    let classpath_entries = classpath_entries(&metadata, &root, &client_jar);
    if let Some(missing) = classpath_entries.iter().find(|path| !path.is_file()) {
        bail!("Не найдена библиотека Minecraft: {}. Запусти проверку/восстановление версии.", missing.display());
    }
    let classpath_separator = if cfg!(target_os = "windows") { ";" } else { ":" };
    let classpath = classpath_entries.iter().map(|p| p.to_string_lossy().to_string()).collect::<Vec<_>>().join(classpath_separator);
    let assets_index = metadata.pointer("/assetIndex/id").and_then(Value::as_str)
        .or_else(|| metadata.get("assets").and_then(Value::as_str)).unwrap_or(version_id);
    let version_type = metadata.get("type").and_then(Value::as_str).unwrap_or("release");
    let uuid_compact = profile.uuid.replace('-', "");

    let access_token = match profile.kind {
        ProfileKind::Offline => "0".to_string(),
        ProfileKind::Microsoft => auth::refresh_minecraft_access_token(&client, &profile.uuid, &settings.oauth_client_id).await?,
    };
    let auth_session = format!("token:{}:{access_token}", uuid_compact);
    let mut values = HashMap::<String, String>::new();
    values.insert("${auth_player_name}".into(), profile.name.clone());
    values.insert("${version_name}".into(), version_id.into());
    values.insert("${game_directory}".into(), game_dir.to_string_lossy().to_string());
    values.insert("${assets_root}".into(), root.join("assets").to_string_lossy().to_string());
    values.insert("${assets_index_name}".into(), assets_index.into());
    values.insert("${auth_uuid}".into(), uuid_compact);
    values.insert("${auth_access_token}".into(), access_token);
    values.insert("${auth_session}".into(), auth_session);
    values.insert("${user_type}".into(), if profile.kind == ProfileKind::Microsoft { "msa" } else { "legacy" }.into());
    values.insert("${version_type}".into(), version_type.into());
    values.insert("${natives_directory}".into(), natives_dir.to_string_lossy().to_string());
    values.insert("${launcher_name}".into(), "ZisMine Launcher".into());
    values.insert("${launcher_version}".into(), env!("CARGO_PKG_VERSION").into());
    values.insert("${classpath}".into(), classpath);
    values.insert("${classpath_separator}".into(), classpath_separator.into());
    values.insert("${library_directory}".into(), root.join("libraries").to_string_lossy().to_string());
    values.insert("${resolution_width}".into(), settings.width.to_string());
    values.insert("${resolution_height}".into(), settings.height.to_string());
    values.insert("${user_properties}".into(), "{}".into());
    values.insert("${clientid}".into(), profile.client_id.clone().unwrap_or_else(|| uuid::Uuid::new_v4().to_string()));
    values.insert("${auth_xuid}".into(), profile.xuid.clone().unwrap_or_default());
    let logging_path = metadata.pointer("/logging/client/file/id").and_then(Value::as_str)
        .map(|id| root.join("assets/log_configs").join(id).to_string_lossy().to_string()).unwrap_or_default();
    values.insert("${path}".into(), logging_path);
    values.insert("${quickPlayPath}".into(), game_dir.join("quickPlay").to_string_lossy().to_string());
    values.insert("${quickPlaySingleplayer}".into(), String::new());
    values.insert("${quickPlayMultiplayer}".into(), String::new());
    values.insert("${quickPlayRealms}".into(), String::new());

    let mut args = Vec::<String>::new();
    let jvm_args = metadata.pointer("/arguments/jvm");
    let game_args = metadata.pointer("/arguments/game");
    if let Some(jvm) = jvm_args.and_then(Value::as_array) {
        args.extend(collect_arguments(jvm, current_os_name()).into_iter().map(|s| substitute(s, &values)));
    } else {
        args.push(format!("-Djava.library.path={}", natives_dir.to_string_lossy()));
        args.push("-cp".into());
        args.push(values.get("${classpath}").cloned().unwrap_or_default());
    }
    args.push(format!("-Xms{}M", settings.min_memory_mb));
    args.push(format!("-Xmx{}M", settings.max_memory_mb));
    if let Some(main_class) = metadata.get("mainClass").and_then(Value::as_str) { args.push(main_class.to_string()); }
    else { bail!("В метаданных версии отсутствует mainClass."); }

    if let Some(game) = game_args.and_then(Value::as_array) {
        args.extend(collect_arguments(game, current_os_name()).into_iter().map(|s| substitute(s, &values)));
    } else if let Some(legacy) = metadata.get("minecraftArguments").and_then(Value::as_str) {
        args.extend(legacy.split_whitespace().map(|s| substitute(s.to_string(), &values)));
    } else {
        bail!("В метаданных версии отсутствуют поддерживаемые game arguments.");
    }
    if !args.iter().any(|v| v == "--width") { args.push("--width".into()); args.push(settings.width.to_string()); }
    if !args.iter().any(|v| v == "--height") { args.push("--height".into()); args.push(settings.height.to_string()); }
    if settings.fullscreen && !args.iter().any(|v| v == "--fullscreen") { args.push("--fullscreen".into()); }

    let launch_java = preferred_launch_java(&java_path);
    let mut command = Command::new(&launch_java);
    command.args(&args).current_dir(&game_dir).stdin(Stdio::null()).stdout(Stdio::piped()).stderr(Stdio::piped());
    #[cfg(target_os = "windows")]
    {
        use std::os::windows::process::CommandExt;
        // CREATE_NO_WINDOW: never spawn a second console window for the game process.
        command.as_std_mut().creation_flags(0x0800_0000);
    }
    let mut child = command.spawn().with_context(|| format!("Не удалось запустить Java: {}", java_path.display()))?;
    let pid = child.id().context("ОС не вернула PID процесса Minecraft")?;
    let stdout = child.stdout.take();
    let stderr = child.stderr.take();
    let app_for_watch = app.clone();
    let show_console = settings.show_console;
    let log_path = game_dir.join("logs").join("latest.log");
    if let Some(parent) = log_path.parent() { tokio::fs::create_dir_all(parent).await?; }
    tokio::fs::write(&log_path, format!("ZisMine Launcher game log\nVersion: {version_id}\nJava: {}\n\n", launch_java.display())).await?;
    tokio::spawn(async move {
        let stdout_task = read_stream(stdout, app_for_watch.clone(), show_console, log_path.clone(), "OUT");
        let stderr_task = read_stream(stderr, app_for_watch.clone(), show_console, log_path.clone(), "ERR");
        let (status, _, _) = tokio::join!(child.wait(), stdout_task, stderr_task);
        let code = status.ok().and_then(|s| s.code());
        if let Ok(mut file) = tokio::fs::OpenOptions::new().create(true).append(true).open(&log_path).await {
            let _ = file.write_all(format!("\nMinecraft process exited with code: {:?}\n", code).as_bytes()).await;
        }
        let _ = app_for_watch.emit("game-exit", serde_json::json!({ "pid": pid, "code": code }));
    });
    Ok((pid, launch_java.to_string_lossy().to_string()))
}

async fn read_stream<R>(stream: Option<R>, app: AppHandle, enabled: bool, log_path: PathBuf, stream_name: &'static str)
where R: tokio::io::AsyncRead + Unpin {
    let Some(stream) = stream else { return; };
    let mut log = tokio::fs::OpenOptions::new().create(true).append(true).open(log_path).await.ok();
    let mut lines = BufReader::new(stream).lines();
    while let Ok(Some(line)) = lines.next_line().await {
        if let Some(file) = log.as_mut() {
            let _ = file.write_all(format!("[{stream_name}] {line}\r\n").as_bytes()).await;
        }
        if enabled { let _ = app.emit("game-log", line); }
    }
}

async fn validate_java_binary(path: &Path, required_major: u32) -> Result<()> {
    let mut command = Command::new(path);
    command.arg("-version").stdout(Stdio::piped()).stderr(Stdio::piped());
    #[cfg(target_os = "windows")]
    {
        use std::os::windows::process::CommandExt;
        command.as_std_mut().creation_flags(0x0800_0000);
    }
    let output = command.output().await
        .with_context(|| format!("Не удалось запустить Java Runtime {}", path.display()))?;
    let text = format!("{}{}", String::from_utf8_lossy(&output.stdout), String::from_utf8_lossy(&output.stderr));
    let major = parse_java_major(&text).context("Не удалось определить major version Java Runtime")?;
    if major != required_major { bail!("Найден Java Runtime {major}, а Minecraft требует {required_major}."); }
    Ok(())
}

fn parse_java_major(output: &str) -> Option<u32> {
    let marker = output.split(['"', '\'']).find(|part| part.chars().next().is_some_and(|c| c.is_ascii_digit()))?;
    let first = marker.split('.').next()?.parse::<u32>().ok()?;
    if first == 1 { marker.split('.').nth(1)?.parse().ok() } else { Some(first) }
}

fn classpath_entries(metadata: &Value, root: &Path, client_jar: &Path) -> Vec<PathBuf> {
    let mut entries = Vec::new();
    if let Some(libraries) = metadata.get("libraries").and_then(Value::as_array) {
        for library in libraries {
            if !rules_allow(library.get("rules"), current_os_name()) { continue; }
            if let Some(path) = library.pointer("/downloads/artifact/path").and_then(Value::as_str) {
                entries.push(root.join("libraries").join(path));
            } else if library.get("downloads").is_none() {
                if let Some(name) = library.get("name").and_then(Value::as_str) {
                let parts: Vec<&str> = name.split(':').collect();
                if parts.len() >= 3 {
                    let group = parts[0].replace('.', "/");
                    let artifact = parts[1]; let version = parts[2];
                    let classifier = parts.get(3).map(|c| format!("-{c}")).unwrap_or_default();
                    entries.push(root.join("libraries").join(format!("{group}/{artifact}/{version}/{artifact}-{version}{classifier}.jar")));
                }
                }
            }
        }
    }
    entries.push(client_jar.to_path_buf());
    entries
}

fn collect_arguments(values: &[Value], os_name: &str) -> Vec<String> {
    let mut output = Vec::new();
    for value in values {
        if let Some(text) = value.as_str() { output.push(text.to_string()); continue; }
        if let Some(rules) = value.get("rules").and_then(Value::as_array) {
            if !rules_allow(Some(&Value::Array(rules.clone())), os_name) { continue; }
        } else if value.get("rules").is_some() { continue; }
        let Some(argument) = value.get("value") else { continue; };
        if let Some(text) = argument.as_str() { output.push(text.to_string()); }
        else if let Some(list) = argument.as_array() { output.extend(list.iter().filter_map(Value::as_str).map(ToOwned::to_owned)); }
    }
    output
}

fn rules_allow(rules: Option<&Value>, os_name: &str) -> bool {
    let Some(list) = rules.and_then(Value::as_array) else { return true; };
    let mut allowed = false;
    for rule in list {
        let mut matches = true;
        if let Some(os) = rule.get("os") {
            if let Some(name) = os.get("name").and_then(Value::as_str) { matches &= name == os_name; }
            if let Some(arch) = os.get("arch").and_then(Value::as_str) {
                if arch == "x86" { matches &= cfg!(target_pointer_width = "32"); }
                if arch == "x86_64" { matches &= cfg!(target_pointer_width = "64"); }
            }
        }
        if let Some(features) = rule.get("features").and_then(Value::as_object) {
            for (_name, value) in features {
                if value.as_bool() == Some(true) { matches = false; }
            }
        }
        if matches { allowed = rule.get("action").and_then(Value::as_str) == Some("allow"); }
    }
    allowed
}

fn current_os_name() -> &'static str {
    if cfg!(target_os = "windows") { "windows" } else if cfg!(target_os = "macos") { "osx" } else { "linux" }
}

fn substitute(value: String, values: &HashMap<String, String>) -> String {
    let mut output = value;
    for (key, replacement) in values { output = output.replace(key, replacement); }
    output
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn java_version_parser_handles_old_and_new_formats() {
        assert_eq!(parse_java_major("openjdk version \"17.0.2\" 2024-01-16"), Some(17));
        assert_eq!(parse_java_major("java version \"1.8.0_402\""), Some(8));
    }
    #[test]
    fn argument_substitution_preserves_spaces() {
        let mut vars = HashMap::new();
        vars.insert("${game_directory}".into(), "/home/player/My Minecraft".into());
        assert_eq!(substitute("--gameDir=${game_directory}".into(), &vars), "--gameDir=/home/player/My Minecraft");
    }
}
