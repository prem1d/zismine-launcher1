#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use sha1::Digest;

mod accounts;
mod auth;
mod minecraft;
mod mods;
mod server;
mod settings;
mod storage;

use anyhow::{Context, Result};
use accounts::{AccountStore, Profile};
use serde::Serialize;
use std::{fs, path::PathBuf, sync::Mutex};
use sysinfo::System;
use tauri::{AppHandle, State};
use tokio_util::sync::CancellationToken;

use crate::{
    minecraft::{install::install_fabric as install_fabric_engine, launch::launch_game as launch_game_engine, manifest::{fetch_manifest, ManifestVersion}, runtime::installed_java_path},
    server::ServerConfig,
    settings::{validate_settings, Settings},
    storage::{app_data_dir, java_runtime_dir, read_json, runtime_base_dir, write_json},
};

const SUPPORTED_MINECRAFT_VERSION: &str = "1.20.1";

struct AppRuntime {
    pending_device_login: Mutex<Option<auth::DeviceLoginSession>>,
    active_install_cancel: Mutex<Option<CancellationToken>>,
}

#[derive(Debug, Serialize)]
struct Bootstrap {
    profiles: Vec<Profile>,
    active_profile_id: Option<String>,
    installed_versions: Vec<String>,
    settings: Settings,
    server: ServerConfig,
    total_memory_mb: u64,
    available_memory_mb: u64,
    java_runtime_dir: String,
    java_runtime_installed: bool,
    server_status: Option<ServerStatus>,
}

#[derive(Debug, Clone, Serialize)]
struct ServerStatus {
    online: bool,
    players_online: Option<u64>,
    players_max: Option<u64>,
}

fn http_client() -> Result<reqwest::Client> {
    Ok(reqwest::Client::builder()
        .user_agent(concat!("ZisMine-Launcher/", env!("CARGO_PKG_VERSION")))
        .connect_timeout(std::time::Duration::from_secs(15))
        .timeout(std::time::Duration::from_secs(180))
        .pool_idle_timeout(std::time::Duration::from_secs(90))
        .build()?)
}

fn read_or_create<T>(path: &PathBuf, default: T) -> Result<T>
where T: serde::de::DeserializeOwned + serde::Serialize + Clone {
    if path.exists() { read_json(path) } else { write_json(path, &default)?; Ok(default) }
}

fn installed_versions(root: &str) -> Vec<String> {
    let minecraft_root = PathBuf::from(root);
    let versions_path = minecraft_root.join("versions");
    let Ok(entries) = fs::read_dir(versions_path) else { return Vec::new(); };
    let mut versions = entries.filter_map(|entry| entry.ok()).filter_map(|entry| {
        let path = entry.path();
        if !path.is_dir() { return None; }
        let id = entry.file_name().to_string_lossy().to_string();
        let marker = fs::read(path.join(".zismine-installed.json")).ok()
            .and_then(|bytes| serde_json::from_slice::<serde_json::Value>(&bytes).ok());
        let api_present = marker.as_ref().map(|value| {
            let Some(api_version) = value.get("fabric_api_version").and_then(serde_json::Value::as_str) else { return false; };
            let Some(expected_hash) = value.get("fabric_api_sha1").and_then(serde_json::Value::as_str) else { return false; };
            let api_path = minecraft_root.join("instances").join(SUPPORTED_MINECRAFT_VERSION).join("mods").join(format!("fabric-api-{api_version}.jar"));
            fs::read(api_path).ok().map(|bytes| format!("{:x}", sha1::Sha1::digest(bytes)).eq_ignore_ascii_case(expected_hash)).unwrap_or(false)
        }).unwrap_or(false);
        (id == SUPPORTED_MINECRAFT_VERSION
            && path.join(format!("{id}.jar")).is_file()
            && path.join(format!("{id}.json")).is_file()
            && api_present
            && marker.as_ref().is_some_and(|value| value.get("loader").and_then(serde_json::Value::as_str) == Some("fabric")
                && value.get("minecraft_version").and_then(serde_json::Value::as_str) == Some(SUPPORTED_MINECRAFT_VERSION)
                && value.get("java_major").and_then(serde_json::Value::as_u64) == Some(17)
                && value.get("completed").and_then(serde_json::Value::as_bool) == Some(true))).then_some(id)
    }).collect::<Vec<_>>();
    versions.sort();
    versions
}

#[tauri::command]
fn get_bootstrap(app: AppHandle) -> Result<Bootstrap, String> {
    (|| -> Result<Bootstrap> {
        let dir = app_data_dir(&app)?;
        let settings_path = dir.join("settings.json");
        let mut settings = read_or_create(&settings_path, Settings::default())?;
        // Migrate older user settings to this release's single supported Minecraft version.
        let mut settings_changed = false;
        if settings.selected_version != SUPPORTED_MINECRAFT_VERSION {
            settings.selected_version = SUPPORTED_MINECRAFT_VERSION.to_string();
            settings_changed = true;
        }
        // Java 17 is always managed by this launcher and kept beside the EXE on Windows.
        if !settings.auto_java || !settings.java_path.is_empty() {
            settings.auto_java = true;
            settings.java_path.clear();
            settings_changed = true;
        }
        if settings.show_console {
            settings.show_console = false;
            settings_changed = true;
        }
        if settings_changed { write_json(&settings_path, &settings)?; }
        let accounts: AccountStore = read_or_create(&dir.join("accounts.json"), AccountStore::default())?;
        let server: ServerConfig = read_or_create(&dir.join("server.json"), ServerConfig::default())?;
        let mut system = System::new();
        system.refresh_memory();
        let runtime_base = runtime_base_dir(&app)?;
        let java_dir_path = java_runtime_dir(&app)?;
        Ok(Bootstrap {
            profiles: accounts.profiles,
            active_profile_id: accounts.active_profile_id,
            installed_versions: installed_versions(&settings.minecraft_dir),
            settings,
            server,
            total_memory_mb: system.total_memory() / 1024 / 1024,
            available_memory_mb: system.available_memory() / 1024 / 1024,
            java_runtime_dir: java_dir_path.to_string_lossy().to_string(),
            java_runtime_installed: installed_java_path(&runtime_base, 17).is_some(),
            server_status: None,
        })
    })().map_err(|e| e.to_string())
}

#[tauri::command]
async fn get_server_status(app: AppHandle) -> Result<Option<ServerStatus>, String> {
    let dir = app_data_dir(&app).map_err(|e| e.to_string())?;
    let server: ServerConfig = read_or_create(&dir.join("server.json"), ServerConfig::default()).map_err(|e| e.to_string())?;
    Ok(query_server_status(&server).await)
}

async fn query_server_status(server: &ServerConfig) -> Option<ServerStatus> {
    let endpoint = server.status_api.trim();
    if endpoint.is_empty() { return None; }
    let parsed = reqwest::Url::parse(endpoint).ok()?;
    if !matches!(parsed.scheme(), "http" | "https") || !parsed.username().is_empty() || parsed.password().is_some() {
        return None;
    }
    let client = reqwest::Client::builder()
        .connect_timeout(std::time::Duration::from_secs(2))
        .timeout(std::time::Duration::from_secs(4))
        .redirect(reqwest::redirect::Policy::limited(3))
        .build().ok()?;
    let response = client.get(parsed).send().await.ok()?.error_for_status().ok()?;
    let body: serde_json::Value = response.json().await.ok()?;
    let online = body.get("online").and_then(serde_json::Value::as_bool)
        .or_else(|| body.get("status").and_then(serde_json::Value::as_str).map(|value| value.eq_ignore_ascii_case("online")))?;
    let players_online = body.get("players_online").and_then(serde_json::Value::as_u64)
        .or_else(|| body.pointer("/players/online").and_then(serde_json::Value::as_u64));
    let players_max = body.get("players_max").and_then(serde_json::Value::as_u64)
        .or_else(|| body.pointer("/players/max").and_then(serde_json::Value::as_u64));
    Some(ServerStatus { online, players_online, players_max })
}

#[tauri::command]
async fn get_manifest_versions(filter: String) -> Result<Vec<ManifestVersion>, String> {
    let client = http_client().map_err(|e| e.to_string())?;
    let manifest = fetch_manifest(&client).await.map_err(|e| e.to_string())?;
    let query = filter.trim().to_lowercase();
    // This ZisMine build intentionally exposes exactly one supported game version.
    let result = manifest.versions.into_iter()
        .filter(|entry| entry.id == SUPPORTED_MINECRAFT_VERSION)
        .filter(|_| query.is_empty() || SUPPORTED_MINECRAFT_VERSION.contains(&query))
        .collect();
    Ok(result)
}

#[tauri::command]
async fn install_fabric(app: AppHandle, version: String, state: State<'_, AppRuntime>) -> Result<(), String> {
    if version != SUPPORTED_MINECRAFT_VERSION { return Err(format!("Поддерживается только Minecraft {SUPPORTED_MINECRAFT_VERSION}.")); }
    let client = http_client().map_err(|e| e.to_string())?;
    let cancellation = CancellationToken::new();
    {
        let mut active = state.active_install_cancel.lock().map_err(|_| "Install lock poisoned".to_string())?;
        if active.is_some() { return Err("Другая установка уже выполняется.".into()); }
        *active = Some(cancellation.clone());
    }
    let result = install_fabric_engine(app, client, &version, cancellation).await;
    if let Ok(mut active) = state.active_install_cancel.lock() { *active = None; }
    result.map_err(|e| e.to_string())
}

#[tauri::command]
fn cancel_install(state: State<'_, AppRuntime>) {
    if let Ok(active) = state.active_install_cancel.lock() { if let Some(token) = active.as_ref() { token.cancel(); } }
}

#[tauri::command]
async fn launch_game(app: AppHandle, version: String, state: State<'_, AppRuntime>) -> Result<LaunchResult, String> {
    if version != SUPPORTED_MINECRAFT_VERSION { return Err(format!("Поддерживается только Minecraft {SUPPORTED_MINECRAFT_VERSION}.")); }
    let client = http_client().map_err(|e| e.to_string())?;
    let cancellation = CancellationToken::new();
    {
        let mut active = state.active_install_cancel.lock().map_err(|_| "Install lock poisoned".to_string())?;
        if active.is_some() { return Err("Загрузка уже выполняется. Дождись её завершения или отмени.".into()); }
        *active = Some(cancellation.clone());
    }
    let result = launch_game_engine(app, client, &version, cancellation).await;
    if let Ok(mut active) = state.active_install_cancel.lock() { *active = None; }
    let (pid, java_path) = result.map_err(|e| e.to_string())?;
    Ok(LaunchResult { pid, java_path })
}

#[derive(Debug, Serialize)]
struct LaunchResult { pid: u32, java_path: String }

#[tauri::command]
fn create_offline_profile(app: AppHandle, name: String) -> Result<Profile, String> {
    (|| -> Result<Profile> {
        let dir = app_data_dir(&app)?;
        let path = dir.join("accounts.json");
        let mut store = read_or_create(&path, AccountStore::default())?;
        let profile = accounts::create_offline_profile(&name)?;
        if store.profiles.iter().any(|p| p.name.eq_ignore_ascii_case(&profile.name)) {
            anyhow::bail!("Профиль с таким ником уже существует.");
        }
        if store.active_profile_id.is_none() { store.active_profile_id = Some(profile.id.clone()); }
        store.profiles.push(profile.clone());
        write_json(&path, &store)?;
        Ok(profile)
    })().map_err(|e| e.to_string())
}

#[tauri::command]
fn delete_profile(app: AppHandle, id: String) -> Result<(), String> {
    (|| -> Result<()> {
        let dir = app_data_dir(&app)?;
        let path = dir.join("accounts.json");
        let mut store: AccountStore = read_or_create(&path, AccountStore::default())?;
        if let Some(profile) = store.profiles.iter().find(|p| p.id == id) {
            if profile.kind == accounts::ProfileKind::Microsoft { let _ = auth::logout(&profile.uuid); }
        }
        store.profiles.retain(|p| p.id != id);
        if store.active_profile_id.as_deref() == Some(&id) { store.active_profile_id = store.profiles.first().map(|p| p.id.clone()); }
        write_json(&path, &store)?;
        Ok(())
    })().map_err(|e| e.to_string())
}

#[tauri::command]
fn set_active_profile(app: AppHandle, id: String) -> Result<(), String> {
    (|| -> Result<()> {
        let dir = app_data_dir(&app)?;
        let path = dir.join("accounts.json");
        let mut store: AccountStore = read_or_create(&path, AccountStore::default())?;
        if !store.profiles.iter().any(|p| p.id == id) { anyhow::bail!("Профиль не найден."); }
        store.active_profile_id = Some(id);
        write_json(&path, &store)?;
        Ok(())
    })().map_err(|e| e.to_string())
}

#[tauri::command]
fn save_settings(app: AppHandle, mut settings: Settings) -> Result<Settings, String> {
    (|| -> Result<Settings> {
        // Java 17 installation and management are automatic; manual paths are not exposed.
        settings.auto_java = true;
        settings.java_path.clear();
        validate_settings(&mut settings)?;
        let dir = app_data_dir(&app)?;
        write_json(&dir.join("settings.json"), &settings)?;
        fs::create_dir_all(&settings.minecraft_dir)?;
        Ok(settings)
    })().map_err(|e| e.to_string())
}

#[tauri::command]
fn reset_settings(app: AppHandle) -> Result<Settings, String> {
    (|| -> Result<Settings> {
        let mut settings = Settings::default();
        let mut system = System::new();
        system.refresh_memory();
        let safe_max = (system.available_memory() / 1024 / 1024).saturating_sub(2048).max(1024);
        settings.max_memory_mb = settings.max_memory_mb.min(safe_max);
        settings.min_memory_mb = settings.min_memory_mb.min(settings.max_memory_mb);
        validate_settings(&mut settings)?;
        let dir = app_data_dir(&app)?;
        write_json(&dir.join("settings.json"), &settings)?;
        fs::create_dir_all(&settings.minecraft_dir)?;
        Ok(settings)
    })().map_err(|e| e.to_string())
}

fn remove_partial_files(directory: &std::path::Path, removed: &mut u64) -> Result<()> {
    let entries = match fs::read_dir(directory) { Ok(entries) => entries, Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(()), Err(error) => return Err(error.into()) };
    for entry in entries {
        let entry = entry?;
        let file_type = entry.file_type()?;
        let path = entry.path();
        if file_type.is_dir() {
            remove_partial_files(&path, removed)?;
        } else if file_type.is_file() && path.extension().and_then(|extension| extension.to_str()) == Some("part") {
            fs::remove_file(path)?;
            *removed += 1;
        }
    }
    Ok(())
}

#[tauri::command]
fn clear_temp_files(app: AppHandle, state: State<'_, AppRuntime>) -> Result<u64, String> {
    (|| -> Result<u64> {
        if state.active_install_cancel.lock().map_err(|_| anyhow::anyhow!("Install lock poisoned"))?.is_some() {
            anyhow::bail!("Нельзя очищать временные файлы во время установки Minecraft.");
        }
        let dir = app_data_dir(&app)?;
        let settings: Settings = read_or_create(&dir.join("settings.json"), Settings::default())?;
        let mut removed = 0;
        remove_partial_files(&PathBuf::from(settings.minecraft_dir), &mut removed)?;
        Ok(removed)
    })().map_err(|e| e.to_string())
}

#[tauri::command]
fn remove_version(app: AppHandle, version: String) -> Result<(), String> {
    (|| -> Result<()> {
        if version != SUPPORTED_MINECRAFT_VERSION {
            anyhow::bail!("В этой версии лаунчера доступна только Minecraft {SUPPORTED_MINECRAFT_VERSION}.");
        }
        let dir = app_data_dir(&app)?;
        let settings: Settings = read_or_create(&dir.join("settings.json"), Settings::default())?;
        let root = PathBuf::from(settings.minecraft_dir);
        let version_dir = root.join("versions").join(&version);
        if version_dir.exists() { fs::remove_dir_all(version_dir).context("Не удалось удалить файлы версии")?; }
        let instance_dir = root.join("instances").join(&version);
        if instance_dir.exists() { fs::remove_dir_all(instance_dir).context("Не удалось удалить папку профиля сборки")?; }
        Ok(())
    })().map_err(|e| e.to_string())
}

#[tauri::command]
async fn microsoft_begin_login(app: AppHandle, state: State<'_, AppRuntime>) -> Result<auth::DeviceCodeStart, String> {
    let dir = app_data_dir(&app).map_err(|e| e.to_string())?;
    let settings: Settings = read_or_create(&dir.join("settings.json"), Settings::default()).map_err(|e| e.to_string())?;
    let client = http_client().map_err(|e| e.to_string())?;
    let (visible, session) = auth::begin_device_login(&client, &settings.oauth_client_id).await.map_err(|e| e.to_string())?;
    *state.pending_device_login.lock().map_err(|_| "Auth lock poisoned".to_string())? = Some(session);
    Ok(visible)
}

#[tauri::command]
async fn microsoft_complete_login(app: AppHandle, state: State<'_, AppRuntime>) -> Result<Profile, String> {
    let session = state.pending_device_login.lock().map_err(|_| "Auth lock poisoned".to_string())?.take()
        .ok_or_else(|| "Сначала начни Microsoft-вход.".to_string())?;
    let dir = app_data_dir(&app).map_err(|e| e.to_string())?;
    let settings: Settings = read_or_create(&dir.join("settings.json"), Settings::default()).map_err(|e| e.to_string())?;
    let client = http_client().map_err(|e| e.to_string())?;
    let profile = auth::finish_device_login(&client, &settings.oauth_client_id, session).await.map_err(|e| e.to_string())?;
    let path = dir.join("accounts.json");
    let mut accounts: AccountStore = read_or_create(&path, AccountStore::default()).map_err(|e| e.to_string())?;
    accounts.profiles.retain(|p| p.id != profile.id);
    accounts.profiles.push(profile.clone());
    accounts.active_profile_id = Some(profile.id.clone());
    write_json(&path, &accounts).map_err(|e| e.to_string())?;
    Ok(profile)
}

#[tauri::command]
fn cancel_microsoft_login(state: State<'_, AppRuntime>) {
    if let Ok(mut pending) = state.pending_device_login.lock() { *pending = None; }
}

#[tauri::command]
fn open_mods_folder(app: AppHandle) -> Result<(), String> {
    let dir = app_data_dir(&app).map_err(|e| e.to_string())?;
    let settings: Settings = read_or_create(&dir.join("settings.json"), Settings::default()).map_err(|e| e.to_string())?;
    let mods_dir = PathBuf::from(settings.minecraft_dir).join("instances").join(SUPPORTED_MINECRAFT_VERSION).join("mods");
    std::fs::create_dir_all(&mods_dir).map_err(|e| format!("Не удалось создать папку модов: {e}"))?;
    #[cfg(target_os = "windows")]
    let mut command = {
        use std::os::windows::process::CommandExt;
        let mut command = std::process::Command::new("explorer.exe");
        command.creation_flags(0x0800_0000);
        command
    };
    #[cfg(target_os = "macos")]
    let mut command = std::process::Command::new("open");
    #[cfg(target_os = "linux")]
    let mut command = std::process::Command::new("xdg-open");
    command.arg(&mods_dir).spawn().map_err(|e| format!("Не удалось открыть папку модов: {e}"))?;
    Ok(())
}

#[tauri::command]
fn list_mods(app: AppHandle) -> Result<Vec<mods::ModInfo>, String> {
    let dir = app_data_dir(&app).map_err(|e| e.to_string())?;
    let settings: Settings = read_or_create(&dir.join("settings.json"), Settings::default()).map_err(|e| e.to_string())?;
    mods::list_mods(&PathBuf::from(settings.minecraft_dir).join("instances").join(SUPPORTED_MINECRAFT_VERSION)).map_err(|e| e.to_string())
}

#[tauri::command]
fn set_mod_enabled(app: AppHandle, file_name: String, enabled: bool) -> Result<(), String> {
    let dir = app_data_dir(&app).map_err(|e| e.to_string())?;
    let settings: Settings = read_or_create(&dir.join("settings.json"), Settings::default()).map_err(|e| e.to_string())?;
    mods::set_mod_enabled(&PathBuf::from(settings.minecraft_dir).join("instances").join(SUPPORTED_MINECRAFT_VERSION), &file_name, enabled).map_err(|e| e.to_string())
}

#[tauri::command]
fn remove_mod(app: AppHandle, file_name: String) -> Result<(), String> {
    let dir = app_data_dir(&app).map_err(|e| e.to_string())?;
    let settings: Settings = read_or_create(&dir.join("settings.json"), Settings::default()).map_err(|e| e.to_string())?;
    mods::remove_mod(&PathBuf::from(settings.minecraft_dir).join("instances").join(SUPPORTED_MINECRAFT_VERSION), &file_name).map_err(|e| e.to_string())
}

fn main() {
    let state = AppRuntime { pending_device_login: Mutex::new(None), active_install_cancel: Mutex::new(None) };
    tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_opener::init())
        .manage(state)
        .invoke_handler(tauri::generate_handler![
            get_bootstrap, get_server_status, get_manifest_versions, install_fabric, cancel_install, launch_game,
            create_offline_profile, delete_profile, set_active_profile,
            save_settings, reset_settings, clear_temp_files, remove_version, microsoft_begin_login,
            microsoft_complete_login, cancel_microsoft_login, open_mods_folder, list_mods, set_mod_enabled, remove_mod
        ])
        .run(tauri::generate_context!())
        .expect("error while running ZisMine Launcher");
}
