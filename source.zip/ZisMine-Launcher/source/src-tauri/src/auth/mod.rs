mod credentials;

use anyhow::{bail, Context, Result};
use reqwest::Client;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::time::Duration;
use tokio::time::{sleep, Instant};

use crate::accounts::{Profile, ProfileKind};

const DEVICE_CODE_ENDPOINT: &str = "https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode";
const TOKEN_ENDPOINT: &str = "https://login.microsoftonline.com/consumers/oauth2/v2.0/token";
const XBOX_AUTH_ENDPOINT: &str = "https://user.auth.xboxlive.com/user/authenticate";
const XSTS_ENDPOINT: &str = "https://xsts.auth.xboxlive.com/xsts/authorize";
const MC_LOGIN_ENDPOINT: &str = "https://api.minecraftservices.com/authentication/login_with_xbox";
const MC_ENTITLEMENTS_ENDPOINT: &str = "https://api.minecraftservices.com/entitlements/mcstore";
const MC_PROFILE_ENDPOINT: &str = "https://api.minecraftservices.com/minecraft/profile";

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DeviceCodeStart {
    pub user_code: String,
    pub verification_uri: String,
    pub message: String,
    pub expires_in: u64,
}

#[derive(Debug, Clone)]
pub struct DeviceLoginSession {
    device_code: String,
    interval_seconds: u64,
    expires_at: Instant,
}

#[derive(Debug, Deserialize)]
struct OAuthDeviceResponse {
    device_code: String,
    user_code: String,
    verification_uri: String,
    message: String,
    expires_in: u64,
    interval: Option<u64>,
}

#[derive(Debug, Deserialize)]
struct OAuthTokenResponse {
    access_token: String,
    refresh_token: Option<String>,
    #[allow(dead_code)]
    expires_in: Option<u64>,
}

pub async fn begin_device_login(client: &Client, client_id: &str) -> Result<(DeviceCodeStart, DeviceLoginSession)> {
    validate_client_id(client_id)?;
    let response = client.post(DEVICE_CODE_ENDPOINT)
        .form(&[("client_id", client_id), ("scope", "XboxLive.signin offline_access")])
        .send().await.context("Не удалось связаться с Microsoft Device Code endpoint")?;
    let response = response.error_for_status().context("Microsoft отклонила запрос Device Code. Проверь Client ID и настройки Public client flow.")?;
    let payload: OAuthDeviceResponse = response.json().await.context("Microsoft вернула некорректный Device Code ответ")?;
    let session = DeviceLoginSession {
        device_code: payload.device_code,
        interval_seconds: payload.interval.unwrap_or(5).max(2),
        expires_at: Instant::now() + Duration::from_secs(payload.expires_in),
    };
    let visible = DeviceCodeStart {
        user_code: payload.user_code,
        verification_uri: payload.verification_uri,
        message: payload.message,
        expires_in: payload.expires_in,
    };
    Ok((visible, session))
}

pub async fn finish_device_login(client: &Client, client_id: &str, session: DeviceLoginSession) -> Result<Profile> {
    let mut interval = session.interval_seconds;
    let token = loop {
        if Instant::now() >= session.expires_at { bail!("Время Microsoft Device Code истекло. Начни вход заново."); }
        sleep(Duration::from_secs(interval)).await;
        let response = client.post(TOKEN_ENDPOINT)
            .form(&[
                ("grant_type", "urn:ietf:params:oauth:grant-type:device_code"),
                ("client_id", client_id),
                ("device_code", session.device_code.as_str()),
            ])
            .send().await.context("Не удалось опросить Microsoft Token endpoint")?;
        if response.status().is_success() {
            break response.json::<OAuthTokenResponse>().await.context("Некорректный Microsoft token response")?;
        }
        let body: Value = response.json().await.unwrap_or(Value::Null);
        match body.get("error").and_then(Value::as_str).unwrap_or_default() {
            "authorization_pending" => continue,
            "slow_down" => { interval = (interval + 5).min(30); continue; }
            "authorization_declined" => bail!("Вход Microsoft был отменён пользователем."),
            "expired_token" => bail!("Код входа Microsoft истёк. Начни заново."),
            "bad_verification_code" => bail!("Microsoft отклонила Device Code."),
            _ => bail!("Ошибка Microsoft OAuth: {}", body.get("error_description").and_then(Value::as_str).unwrap_or("неизвестная ошибка")),
        }
    };

    let refresh = token.refresh_token.context("Microsoft не выдала refresh token. Проверь scope offline_access.")?;
    let (_minecraft_access_token, profile) = exchange_microsoft_access_token(client, &token.access_token).await?;
    credentials::store_refresh_token(&profile.uuid, &refresh)?;
    Ok(profile)
}

pub async fn refresh_minecraft_access_token(client: &Client, profile_id: &str, client_id: &str) -> Result<String> {
    let refresh_token = credentials::get_refresh_token(profile_id)?;
    let response = client.post(TOKEN_ENDPOINT)
        .form(&[
            ("client_id", client_id),
            ("grant_type", "refresh_token"),
            ("refresh_token", refresh_token.as_str()),
            ("scope", "XboxLive.signin offline_access"),
        ])
        .send().await.context("Не удалось обновить Microsoft token")?;
    let token_response: OAuthTokenResponse = response.error_for_status()
        .context("Microsoft refresh token истёк или отозван. Войди повторно.")?
        .json().await.context("Некорректный Microsoft refresh response")?;
    if let Some(new_refresh) = token_response.refresh_token {
        credentials::store_refresh_token(profile_id, &new_refresh)?;
    }
    let (minecraft_access_token, _profile) = exchange_microsoft_access_token(client, &token_response.access_token).await?;
    Ok(minecraft_access_token)
}

pub fn logout(profile_id: &str) -> Result<()> { credentials::delete_refresh_token(profile_id) }

async fn exchange_microsoft_access_token(client: &Client, microsoft_access_token: &str) -> Result<(String, Profile)> {
    let xbox_response: Value = client.post(XBOX_AUTH_ENDPOINT).json(&json!({
        "Properties": { "AuthMethod": "RPS", "SiteName": "user.auth.xboxlive.com", "RpsTicket": format!("d={microsoft_access_token}") },
        "RelyingParty": "http://auth.xboxlive.com",
        "TokenType": "JWT"
    })).send().await.context("Xbox Live authentication request failed")?
        .error_for_status().context("Xbox Live отклонила Microsoft токен")?
        .json().await.context("Некорректный Xbox Live ответ")?;
    let xbox_token = required_string(&xbox_response, "Token")?;
    let user_hash = xbox_response.pointer("/DisplayClaims/xui/0/uhs").and_then(Value::as_str)
        .context("Xbox Live не вернула user hash")?.to_string();
    let xuid = xbox_response.pointer("/DisplayClaims/xui/0/xid").and_then(Value::as_str).map(ToOwned::to_owned);

    let xsts_response: Value = client.post(XSTS_ENDPOINT).json(&json!({
        "Properties": { "SandboxId": "RETAIL", "UserTokens": [xbox_token] },
        "RelyingParty": "rp://api.minecraftservices.com/",
        "TokenType": "JWT"
    })).send().await.context("Xbox XSTS request failed")?
        .error_for_status().context("Xbox XSTS не выдала игровую авторизацию")?
        .json().await.context("Некорректный Xbox XSTS ответ")?;
    let xsts_token = required_string(&xsts_response, "Token")?;
    let xsts_hash = xsts_response.pointer("/DisplayClaims/xui/0/uhs").and_then(Value::as_str).unwrap_or(&user_hash);

    let mc_response: Value = client.post(MC_LOGIN_ENDPOINT).json(&json!({
        "identityToken": format!("XBL3.0 x={xsts_hash};{xsts_token}")
    })).send().await.context("Minecraft Services login request failed")?
        .error_for_status().context("Minecraft Services отклонила Xbox авторизацию")?
        .json().await.context("Некорректный Minecraft Services token response")?;
    let minecraft_token = required_string(&mc_response, "access_token")?;

    let entitlements: Value = client.get(MC_ENTITLEMENTS_ENDPOINT).bearer_auth(&minecraft_token)
        .send().await.context("Не удалось проверить Minecraft entitlements")?
        .error_for_status().context("Не удалось проверить право владения Minecraft")?
        .json().await.context("Некорректный ответ Minecraft entitlements")?;
    let items = entitlements.get("items").and_then(Value::as_array).cloned().unwrap_or_default();
    let owns_java = items.iter().any(|item| {
        let name = item.get("name").and_then(Value::as_str).unwrap_or_default();
        name == "game_minecraft" || name == "product_minecraft"
    });
    if !owns_java { bail!("Для этого Microsoft-аккаунта не найдена лицензия Minecraft Java Edition."); }

    let game_profile: Value = client.get(MC_PROFILE_ENDPOINT).bearer_auth(&minecraft_token)
        .send().await.context("Не удалось получить Minecraft Java профиль")?
        .error_for_status().context("Minecraft Java профиль отсутствует или недоступен")?
        .json().await.context("Некорректный Minecraft Java профиль")?;
    let id = required_string(&game_profile, "id")?;
    let name = required_string(&game_profile, "name")?;
    let skin_url = extract_skin_url(&game_profile);
    let normalized_uuid = if id.len() == 32 {
        format!("{}-{}-{}-{}-{}", &id[0..8], &id[8..12], &id[12..16], &id[16..20], &id[20..32])
    } else { id };
    let profile = Profile { id: normalized_uuid.clone(), name, kind: ProfileKind::Microsoft, uuid: normalized_uuid, xuid, client_id: Some(uuid::Uuid::new_v4().to_string()), skin_url };
    Ok((minecraft_token, profile))
}

fn extract_skin_url(profile: &Value) -> Option<String> {
    let skins = profile.get("skins")?.as_array()?;
    for skin in skins {
        let raw = skin.get("url")?.as_str()?;
        let mut url = reqwest::Url::parse(raw).ok()?;
        if url.host_str() != Some("textures.minecraft.net") || !matches!(url.scheme(), "http" | "https") {
            continue;
        }
        url.set_scheme("https").ok()?;
        return Some(url.to_string());
    }
    None
}

fn required_string(value: &Value, key: &str) -> Result<String> {
    value.get(key).and_then(Value::as_str).map(ToOwned::to_owned)
        .with_context(|| format!("В ответе авторизации отсутствует поле {key}"))
}

fn validate_client_id(client_id: &str) -> Result<()> {
    let parsed = uuid::Uuid::parse_str(client_id.trim());
    if parsed.is_err() { bail!("Укажи корректный Microsoft OAuth Application (client) ID в настройках лаунчера."); }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn only_accepts_official_mojang_skin_texture_urls() {
        let good = json!({"skins":[{"url":"http://textures.minecraft.net/texture/abc123"}]});
        assert_eq!(extract_skin_url(&good).as_deref(), Some("https://textures.minecraft.net/texture/abc123"));
        let bad = json!({"skins":[{"url":"https://example.com/skin.png"}]});
        assert_eq!(extract_skin_url(&bad), None);
    }
}
