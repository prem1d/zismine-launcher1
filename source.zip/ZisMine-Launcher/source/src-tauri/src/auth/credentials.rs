use anyhow::{Context, Result};
use keyring::Entry;

const SERVICE: &str = "ru.zismine.launcher";

pub fn store_refresh_token(account_id: &str, token: &str) -> Result<()> {
    let entry = Entry::new(SERVICE, &format!("microsoft-refresh-{account_id}"))
        .context("Не удалось открыть системное хранилище учётных данных")?;
    entry.set_password(token).context("Не удалось сохранить токен в защищённое хранилище")?;
    Ok(())
}

pub fn get_refresh_token(account_id: &str) -> Result<String> {
    let entry = Entry::new(SERVICE, &format!("microsoft-refresh-{account_id}"))
        .context("Не удалось открыть системное хранилище учётных данных")?;
    entry.get_password().context("Refresh token отсутствует в системном хранилище. Войдите в аккаунт ещё раз.")
}

pub fn delete_refresh_token(account_id: &str) -> Result<()> {
    let entry = Entry::new(SERVICE, &format!("microsoft-refresh-{account_id}"))
        .context("Не удалось открыть системное хранилище учётных данных")?;
    let _ = entry.delete_credential();
    Ok(())
}
