use anyhow::{bail, Result};
use serde::{Deserialize, Serialize};
use std::path::Path;
use uuid::Uuid;

use crate::storage::{read_json, write_json};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum ProfileKind { Offline, Microsoft }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Profile {
    pub id: String,
    pub name: String,
    pub kind: ProfileKind,
    pub uuid: String,
    #[serde(default)]
    pub xuid: Option<String>,
    #[serde(default)]
    pub client_id: Option<String>,
    #[serde(default)]
    pub skin_url: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct AccountStore {
    pub profiles: Vec<Profile>,
    pub active_profile_id: Option<String>,
}

pub fn load(path: &Path) -> Result<AccountStore> {
    if !path.exists() { return Ok(AccountStore::default()); }
    read_json(path)
}

pub fn save(path: &Path, store: &AccountStore) -> Result<()> { write_json(path, store) }

pub fn create_offline_profile(name: &str) -> Result<Profile> {
    let clean = name.trim();
    if !(3..=16).contains(&clean.len()) || !clean.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'_') {
        bail!("Ник должен содержать 3–16 символов: A–Z, a–z, 0–9 или _.");
    }
    let digest = md5::compute(format!("OfflinePlayer:{clean}").as_bytes());
    let mut bytes = digest.0;
    bytes[6] = (bytes[6] & 0x0f) | 0x30;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    let offline_uuid = Uuid::from_bytes(bytes).to_string();
    Ok(Profile { id: Uuid::new_v4().to_string(), name: clean.to_string(), kind: ProfileKind::Offline, uuid: offline_uuid, xuid: None, client_id: Some(Uuid::new_v4().to_string()), skin_url: None })
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn offline_profile_uses_offline_uuid_and_validates_name() {
        let a = create_offline_profile("ZisPlayer").unwrap();
        let b = create_offline_profile("ZisPlayer").unwrap();
        assert_eq!(a.uuid, b.uuid);
        assert_ne!(a.id, b.id);
        assert!(create_offline_profile("ab").is_err());
        assert!(create_offline_profile("ИмяИгрока").is_err());
    }
}
