use anyhow::{bail, Result};
use directories::BaseDirs;
use serde::{Deserialize, Serialize};
use std::path::PathBuf;
use sysinfo::System;

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct Settings {
    pub minecraft_dir: String,
    pub selected_version: String,
    pub min_memory_mb: u64,
    pub max_memory_mb: u64,
    pub java_path: String,
    pub auto_java: bool,
    pub width: u32,
    pub height: u32,
    pub fullscreen: bool,
    pub language: String,
    pub show_console: bool,
    pub check_updates: bool,
    pub oauth_client_id: String,
}

impl Default for Settings {
    fn default() -> Self {
        Self {
            minecraft_dir: default_minecraft_dir().to_string_lossy().to_string(),
            selected_version: "1.20.1".into(),
            min_memory_mb: 1024,
            max_memory_mb: 4096,
            java_path: String::new(),
            auto_java: true,
            width: 1280,
            height: 720,
            fullscreen: false,
            language: "ru".into(),
            show_console: false,
            check_updates: true,
            oauth_client_id: String::new(),
        }
    }
}

pub fn default_minecraft_dir() -> PathBuf {
    if let Some(base) = BaseDirs::new() {
        #[cfg(target_os = "windows")]
        { return base.data_dir().join(".minecraft"); }
        #[cfg(target_os = "macos")]
        { return base.data_dir().join("minecraft"); }
        #[cfg(target_os = "linux")]
        { return base.home_dir().join(".minecraft"); }
    }
    PathBuf::from(".minecraft")
}

pub fn validate_settings(settings: &mut Settings) -> Result<()> {
    if settings.selected_version != "1.20.1" {
        bail!("В этой версии ZisMine Launcher поддерживается только Minecraft 1.20.1 Fabric.");
    }
    if settings.width < 640 || settings.width > 7680 || settings.height < 480 || settings.height > 4320 {
        bail!("Разрешение окна должно быть в диапазоне 640×480 — 7680×4320.");
    }
    if settings.min_memory_mb < 512 || settings.max_memory_mb < 1024 || settings.min_memory_mb > settings.max_memory_mb {
        bail!("Проверь минимальную и максимальную память JVM.");
    }
    let mut system = System::new();
    system.refresh_memory();
    let available_mb = system.available_memory() / 1024 / 1024;
    let safe_max = available_mb.saturating_sub(2048).max(1024);
    if settings.max_memory_mb > safe_max {
        bail!("Слишком много RAM. Безопасный максимум на этом компьютере: {safe_max} MB.");
    }
    if settings.minecraft_dir.trim().is_empty() {
        settings.minecraft_dir = default_minecraft_dir().to_string_lossy().to_string();
    }
    if !matches!(settings.language.as_str(), "ru" | "en") { settings.language = "ru".into(); }
    Ok(())
}
