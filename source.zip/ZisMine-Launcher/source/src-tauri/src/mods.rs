use anyhow::{bail, Context, Result};
use serde::Serialize;
use serde_json::Value;
use std::{fs, path::{Component, Path}};
use zip::ZipArchive;

#[derive(Debug, Clone, Serialize)]
pub struct ModInfo {
    pub file_name: String,
    pub name: String,
    pub version: String,
    pub description: String,
    pub compatibility: String,
    pub enabled: bool,
    pub essential: bool,
}

pub fn list_mods(minecraft_root: &Path) -> Result<Vec<ModInfo>> {
    let mods_dir = minecraft_root.join("mods");
    let disabled_dir = minecraft_root.join("mods-disabled");
    fs::create_dir_all(&mods_dir)?;
    fs::create_dir_all(&disabled_dir)?;
    let mut result = Vec::new();
    for (dir, enabled) in [(&mods_dir, true), (&disabled_dir, false)] {
        for entry in fs::read_dir(dir)? {
            let entry = entry?;
            if !entry.file_type()?.is_file() { continue; }
            let path = entry.path();
            if path.extension().and_then(|ext| ext.to_str()) != Some("jar") { continue; }
            let file_name = entry.file_name().to_string_lossy().to_string();
            let (name, version, description, id, compatibility) = read_mod_descriptor(&path)
                .unwrap_or_else(|_| (path.file_stem().and_then(|s| s.to_str()).unwrap_or(&file_name).replace('_', " ").replace('-', " "), "Неизвестно".into(), "Описание не указано".into(), String::new(), "unknown".into()));
            let essential = id == "fabric-api" || file_name.starts_with("fabric-api-");
            result.push(ModInfo { file_name, name, version, description, compatibility, enabled, essential });
        }
    }
    result.sort_by(|a, b| b.essential.cmp(&a.essential).then_with(|| a.name.to_lowercase().cmp(&b.name.to_lowercase())));
    Ok(result)
}

fn read_mod_descriptor(path: &Path) -> Result<(String, String, String, String, String)> {
    let file = fs::File::open(path).with_context(|| format!("Не удалось открыть {}", path.display()))?;
    let mut archive = ZipArchive::new(file).context("Файл мода не является корректным JAR/ZIP")?;
    let mut entry = archive.by_name("fabric.mod.json").context("fabric.mod.json отсутствует")?;
    if entry.size() > 256 * 1024 { bail!("fabric.mod.json слишком большой."); }
    let mut bytes = Vec::new();
    std::io::Read::read_to_end(&mut entry, &mut bytes)?;
    let metadata: Value = serde_json::from_slice(&bytes).context("fabric.mod.json повреждён")?;
    let compatibility = minecraft_compatibility(metadata.pointer("/depends/minecraft").and_then(Value::as_str));
    Ok((
        metadata.get("name").and_then(Value::as_str).unwrap_or("Без названия").to_string(),
        metadata.get("version").and_then(Value::as_str).unwrap_or("Неизвестно").to_string(),
        metadata.get("description").and_then(Value::as_str).unwrap_or("Описание не указано").to_string(),
        metadata.get("id").and_then(Value::as_str).unwrap_or_default().to_string(),
        compatibility,
    ))
}

// Conservative SemVer-like check for Fabric's common Minecraft dependency syntax.
// Unknown syntax is reported as unknown rather than falsely claiming compatibility.
fn minecraft_compatibility(requirement: Option<&str>) -> String {
    let Some(requirement) = requirement.map(str::trim).filter(|value| !value.is_empty()) else { return "unknown".into(); };
    if requirement == "*" { return "compatible".into(); }
    let target = [1_u64, 20, 1];
    let alternatives = requirement.split("||");
    let mut parsed_any = false;
    for alternative in alternatives {
        let mut accepted = true;
        for raw in alternative.split(|c: char| c == ',' || c.is_whitespace()).filter(|part| !part.is_empty()) {
            let (operator, version_text) = if let Some(value) = raw.strip_prefix(">=") { (">=", value) }
                else if let Some(value) = raw.strip_prefix("<=") { ("<=", value) }
                else if let Some(value) = raw.strip_prefix('>') { (">", value) }
                else if let Some(value) = raw.strip_prefix('<') { ("<", value) }
                else if let Some(value) = raw.strip_prefix('=') { ("=", value) }
                else if let Some(value) = raw.strip_prefix('^') { ("^", value) }
                else if let Some(value) = raw.strip_prefix('~') { ("~", value) }
                else { ("=", raw) };
            let cleaned = version_text.trim_start_matches('v');
            if cleaned.contains('*') || cleaned.contains('x') || cleaned.contains('X') {
                let prefix = cleaned.trim_end_matches(|c: char| matches!(c, '*' | 'x' | 'X' | '.'));
                if !"1.20.1".starts_with(prefix) { accepted = false; }
                parsed_any = true;
                continue;
            }
            let mut parts = cleaned.split('.');
            let mut values = [0_u64; 3];
            let mut valid = true;
            for slot in &mut values {
                if let Some(part) = parts.next() {
                    let digits: String = part.chars().take_while(|c| c.is_ascii_digit()).collect();
                    if digits.is_empty() { valid = false; break; }
                    if let Ok(value) = digits.parse() { *slot = value; } else { valid = false; break; }
                }
            }
            if !valid || parts.next().is_some() { accepted = false; continue; }
            parsed_any = true;
            let cmp = target.cmp(&values);
            let matches = match operator {
                ">=" => cmp != std::cmp::Ordering::Less,
                "<=" => cmp != std::cmp::Ordering::Greater,
                ">" => cmp == std::cmp::Ordering::Greater,
                "<" => cmp == std::cmp::Ordering::Less,
                "^" => cmp != std::cmp::Ordering::Less && target[0] == values[0],
                "~" => cmp != std::cmp::Ordering::Less && target[0] == values[0] && target[1] == values[1],
                _ => cmp == std::cmp::Ordering::Equal,
            };
            if !matches { accepted = false; }
        }
        if accepted && parsed_any { return "compatible".into(); }
    }
    if parsed_any { "incompatible".into() } else { "unknown".into() }
}

fn is_fabric_api_file(path: &Path, file_name: &str) -> bool {
    file_name.starts_with("fabric-api-") || read_mod_descriptor(path)
        .map(|(_, _, _, id, _)| id == "fabric-api")
        .unwrap_or(false)
}

fn validate_file_name(file_name: &str) -> Result<()> {
    let path = Path::new(file_name);
    if path.components().count() != 1 || !path.components().all(|part| matches!(part, Component::Normal(_)))
        || path.extension().and_then(|ext| ext.to_str()) != Some("jar") {
        bail!("Недопустимое имя файла мода.");
    }
    Ok(())
}

pub fn set_mod_enabled(minecraft_root: &Path, file_name: &str, enabled: bool) -> Result<()> {
    validate_file_name(file_name)?;
    let mods_dir = minecraft_root.join("mods");
    let disabled_dir = minecraft_root.join("mods-disabled");
    fs::create_dir_all(&disabled_dir)?;
    let (source, target) = if enabled { (disabled_dir.join(file_name), mods_dir.join(file_name)) }
        else { (mods_dir.join(file_name), disabled_dir.join(file_name)) };
    if !source.is_file() { bail!("Файл мода не найден."); }
    if is_fabric_api_file(&source, file_name) { bail!("Fabric API — обязательный компонент сборки, его нельзя отключить."); }
    if target.exists() { bail!("В папке назначения уже есть файл с таким именем."); }
    fs::rename(source, target).context("Не удалось изменить состояние мода")?;
    Ok(())
}

pub fn remove_mod(minecraft_root: &Path, file_name: &str) -> Result<()> {
    validate_file_name(file_name)?;
    let mods_dir = minecraft_root.join("mods");
    let disabled_dir = minecraft_root.join("mods-disabled");
    let paths = [mods_dir.join(file_name), disabled_dir.join(file_name)];
    let Some(path) = paths.iter().find(|path| path.is_file()) else { bail!("Файл мода не найден."); };
    if is_fabric_api_file(path, file_name) { bail!("Fabric API — обязательный компонент сборки, его нельзя удалить."); }
    fs::remove_file(path).context("Не удалось удалить мод")?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn mod_names_reject_traversal() {
        assert!(validate_file_name("../bad.jar").is_err());
        assert!(validate_file_name("good-mod.jar").is_ok());
        assert!(validate_file_name("not-a-jar.txt").is_err());
    }
    #[test]
    fn recognizes_fabric_api_by_descriptor_even_if_renamed() {
        assert!("fabric-api-0.92.6+1.20.1.jar".starts_with("fabric-api-"));
    }
    #[test]
    fn checks_common_fabric_minecraft_requirements() {
        assert_eq!(minecraft_compatibility(Some("1.20.1")), "compatible");
        assert_eq!(minecraft_compatibility(Some(">=1.20.1 <1.21")), "compatible");
        assert_eq!(minecraft_compatibility(Some("1.19.4")), "incompatible");
        assert_eq!(minecraft_compatibility(None), "unknown");
    }
}
