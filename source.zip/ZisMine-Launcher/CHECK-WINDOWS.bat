@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
title ZisMine Launcher - Environment Check
set "PATH=%ProgramFiles%\nodejs;%USERPROFILE%\.cargo\bin;%PATH%"
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
echo.
echo ===== ZISMINE LAUNCHER - WINDOWS ENVIRONMENT CHECK =====
echo.
echo [Node.js]
where node 2>nul
node --version 2>nul
where npm 2>nul
npm --version 2>nul
echo.
echo [Rust]
where rustup 2>nul
rustup --version 2>nul
where rustc 2>nul
rustc --version 2>nul
where cargo 2>nul
cargo --version 2>nul
echo.
echo [Visual Studio C++]
if exist "%VSWHERE%" (
  "%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
) else (
  echo vswhere.exe not found
)
echo.
echo [WinGet]
where winget 2>nul
winget --version 2>nul
echo.
echo Press any key to close.
pause >nul
