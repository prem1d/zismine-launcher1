# Changelog

## 0.2.0 — Fabric Edition / Redesign (2026-11-06)

- Закреплён единственный игровой профиль Minecraft 1.20.1 + Fabric Loader + Fabric API; предыдущая версия удалена из активной логики.
- Добавлены загрузка Fabric Loader из Fabric Meta, объединение launch profile, загрузка совместимого Fabric API с проверкой SHA-1.
- Java 17 определяется из официальных метаданных и устанавливается через Mojang Runtime Manifest в `runtime/` рядом с EXE на Windows.
- Добавлен менеджер модов: чтение `fabric.mod.json`, включение/отключение, удаление, защита Fabric API и осторожный статус зависимости Minecraft 1.20.1.
- Переработана тема в красно-графитовых цветах, сохранён знак Z; новые приложение/бренд SVG/PNG/ICO assets.
- Добавлено собственное borderless окно Tauri с контролами; Release использует Windows GUI subsystem.
- Java запускается через `javaw.exe` без отдельного окна; stdout/stderr игры всегда сохраняются в `logs/latest.log`.
- Сохранён существующий Microsoft OAuth/Xbox/XSTS/Minecraft Services entitlement flow и системное хранение refresh token.
- Добавлены дополнительные статические регрессионные проверки.

## 0.1.1 — Java runtime and UI hardening

- Исправлено чтение вложенных JSON-полей через корректный JSON Pointer.
- Добавлена проверка целостности установок и Runtime.

## 0.1.0-dev — Initial Tauri launcher

- Создан Tauri 2 + Rust + React + TypeScript проект, добавлены setup/build scripts, Microsoft auth, локальные профили и Minecraft download pipeline.
