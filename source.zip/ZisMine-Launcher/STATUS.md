# Project status — 2026-11-06

## Текущий профиль

- Release: `0.2.0`
- Game: `Minecraft 1.20.1` only
- Loader: Fabric Loader
- Required mod: Fabric API (downloaded from Fabric Maven into `instances/1.20.1/mods/`)
- Java: 17, Mojang Runtime Manifest
- Main target: Windows 10/11 x64, NSIS current-user installer
- Auth: Microsoft Device Code + Xbox/XSTS + Minecraft Services entitlement/profile check; requires configured public OAuth Client ID

## Реализовано в исходниках

- Красная бренд-система с сохранением знака Z и обновлёнными иконками.
- Borderless Tauri titlebar and custom window controls.
- Home, Accounts, Mods and Settings pages.
- Fabric installation pipeline and Fabric API download.
- Java 17 installation next to the Windows executable; damaged/missing runtime repair on launch.
- Basic JAR mod manager with enable/disable/remove; Fabric API protected. Minecraft dependency status is conservative: unknown metadata is not marked compatible.
- Release console suppression and persistent game logs.

## Проверки и ограничения

- Static Minecraft regression tests and Windows BAT script checks are included.
- Rust/Cargo compilation and actual Windows EXE bundling were not executed in this environment.
- Live Mojang/Fabric downloads, Microsoft login with an actual licensed account, mod compatibility against arbitrary third-party mods, and launching to the Minecraft main menu require a Windows acceptance test.
- No binary installer is included in this source archive.
