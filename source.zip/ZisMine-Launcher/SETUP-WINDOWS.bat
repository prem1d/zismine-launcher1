@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
title ZisMine Launcher - Setup Windows
color 0A

rem Keep the current console open. WinGet/Visual Studio may request UAC only
rem for the individual machine-wide package that needs it; this script does
rem not relaunch itself and immediately close the original window.
set "ROOT=%~dp0"
set "PROJECT=%ROOT%source"
set "LOG=%ROOT%SETUP-WINDOWS.log"
cd /d "%ROOT%"

>"%LOG%" echo ZisMine Launcher Windows setup log
>>"%LOG%" echo Started: %DATE% %TIME%
>>"%LOG%" echo Root: %ROOT%

echo.
echo ================================================================
echo              ZISMINE LAUNCHER - WINDOWS SETUP
echo ================================================================
echo.
echo This installs developer tools on your PC:
echo   1. Node.js LTS and npm
echo   2. Rust stable MSVC toolchain
echo   3. Visual Studio C++ Build Tools and Windows SDK
echo   4. Project dependencies from npm
echo.
echo This is for BUILDING the launcher. Players do NOT need these tools.
echo The installer will keep this window open and show errors.
echo.

if not exist "%PROJECT%\package.json" goto :missing_project

if /I "%PROCESSOR_ARCHITECTURE%"=="AMD64" goto :architecture_ok
if /I "%PROCESSOR_ARCHITEW6432%"=="AMD64" goto :architecture_ok
goto :unsupported_architecture

:architecture_ok
where winget >nul 2>&1
if errorlevel 1 goto :missing_winget

>>"%LOG%" echo.
>>"%LOG%" echo [1/4] Node.js

echo [1/4] Checking Node.js and npm...
where node >nul 2>&1
if errorlevel 1 goto :install_node

goto :node_found

:install_node
echo Node.js is not installed. Installing Node.js LTS with WinGet...
winget install --id OpenJS.NodeJS.LTS --exact --source winget --accept-package-agreements --accept-source-agreements --silent
set "RC=%ERRORLEVEL%"
>>"%LOG%" echo Node.js WinGet exit code: %RC%
if not "%RC%"=="0" goto :node_failed

:node_found
if exist "%ProgramFiles%\nodejs\node.exe" set "PATH=%ProgramFiles%\nodejs;%PATH%"
if exist "%ProgramFiles%\nodejs\npm.cmd" set "PATH=%ProgramFiles%\nodejs;%PATH%"
where node >nul 2>&1
if errorlevel 1 goto :node_not_on_path
where npm >nul 2>&1
if errorlevel 1 goto :npm_missing
for /f "delims=" %%V in ('node -p "process.versions.node" 2^>nul') do set "NODE_VERSION=%%V"
echo Found Node.js %NODE_VERSION%
node -e "const [m,n]=process.versions.node.split('.').map(Number);process.exit((m===20&&n>=19)||(m>=22&&((m>22)||n>=12))?0:1)" >nul 2>&1
if errorlevel 1 goto :node_too_old

>>"%LOG%" echo Node.js version: %NODE_VERSION%

>>"%LOG%" echo.
>>"%LOG%" echo [2/4] Rust

echo.
echo [2/4] Checking Rust and Cargo...
if exist "%USERPROFILE%\.cargo\bin" set "PATH=%USERPROFILE%\.cargo\bin;%PATH%"
where rustup >nul 2>&1
if errorlevel 1 goto :install_rust

goto :rust_found

:install_rust
echo Rustup is not installed. Installing it with WinGet...
winget install --id Rustlang.Rustup --exact --source winget --accept-package-agreements --accept-source-agreements --silent
set "RC=%ERRORLEVEL%"
>>"%LOG%" echo Rustup WinGet exit code: %RC%
if not "%RC%"=="0" goto :rust_failed
if exist "%USERPROFILE%\.cargo\bin" set "PATH=%USERPROFILE%\.cargo\bin;%PATH%"

:rust_found
where rustup >nul 2>&1
if errorlevel 1 goto :rust_not_found

echo Installing/updating the stable MSVC Rust toolchain...
rustup toolchain install stable-x86_64-pc-windows-msvc --profile minimal
set "RC=%ERRORLEVEL%"
>>"%LOG%" echo Rust toolchain install exit code: %RC%
if not "%RC%"=="0" goto :rust_toolchain_failed

rustup default stable-x86_64-pc-windows-msvc
set "RC=%ERRORLEVEL%"
>>"%LOG%" echo Rust default toolchain exit code: %RC%
if not "%RC%"=="0" goto :rust_default_failed

where cargo >nul 2>&1
if errorlevel 1 goto :cargo_not_found
where rustc >nul 2>&1
if errorlevel 1 goto :rustc_not_found
for /f "delims=" %%V in ('rustc --version 2^>nul') do set "RUST_VERSION=%%V"
echo Found %RUST_VERSION%
>>"%LOG%" echo %RUST_VERSION%

>>"%LOG%" echo.
>>"%LOG%" echo [3/4] Microsoft C++ Build Tools

echo.
echo [3/4] Checking Microsoft C++ Build Tools...
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
set "VS_PATH="
if not exist "%VSWHERE%" goto :install_vs
for /f "usebackq delims=" %%I in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VS_PATH=%%I"
if defined VS_PATH goto :vs_found

rem If Visual Studio exists without the C++ workload, add the workload to it.
set "VS_PATH="
for /f "usebackq delims=" %%I in (`"%VSWHERE%" -latest -products * -property installationPath`) do if not defined VS_PATH set "VS_PATH=%%I"
if defined VS_PATH goto :modify_vs

goto :install_vs

:modify_vs
echo Visual Studio exists, but its C++ compiler workload is missing.
set "VS_SETUP=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\setup.exe"
if not exist "%VS_SETUP%" goto :vs_installer_missing
start "" /wait "%VS_SETUP%" modify --installPath "%VS_PATH%" --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended --passive --norestart
set "RC=%ERRORLEVEL%"
>>"%LOG%" echo Visual Studio modify exit code: %RC%
if not "%RC%"=="0" goto :vs_modify_failed
goto :verify_vs

:install_vs
echo Installing Visual Studio 2022 Build Tools with Desktop development with C++.
echo This step is large and may take a while. Keep this window open.
winget install --id Microsoft.VisualStudio.2022.BuildTools --exact --source winget --accept-package-agreements --accept-source-agreements --override "--wait --passive --norestart --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended"
set "RC=%ERRORLEVEL%"
>>"%LOG%" echo Visual Studio Build Tools WinGet exit code: %RC%
if not "%RC%"=="0" goto :vs_install_failed

:verify_vs
set "VS_PATH="
if not exist "%VSWHERE%" goto :vswhere_missing
for /f "usebackq delims=" %%I in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VS_PATH=%%I"
if not defined VS_PATH goto :vs_component_missing

:vs_found
echo C++ Build Tools found: %VS_PATH%
>>"%LOG%" echo C++ Build Tools path: %VS_PATH%

>>"%LOG%" echo.
>>"%LOG%" echo [4/4] npm dependencies

echo.
echo [4/4] Installing project dependencies...
pushd "%PROJECT%"
call npm install --no-audit --no-fund
set "RC=%ERRORLEVEL%"
popd
>>"%LOG%" echo npm install exit code: %RC%
if not "%RC%"=="0" goto :npm_install_failed

>>"%LOG%" echo.
>>"%LOG%" echo Setup completed: %DATE% %TIME%

echo.
echo ================================================================
echo              SETUP COMPLETED SUCCESSFULLY
echo ================================================================
echo.
echo All required developer tools are installed.
echo Next: run BUILD-WINDOWS.bat to build the Windows EXE installer.
echo For EXE + MSI: BUILD-WINDOWS.bat all
echo.
echo Setup log: "%LOG%"
echo.
pause
exit /b 0

:missing_project
echo [ERROR] source\package.json was not found.
echo Extract the ENTIRE ZIP archive, then run this BAT from the ZisMine-Launcher folder.
goto :failed

:unsupported_architecture
echo [ERROR] This setup supports Windows x64 only.
goto :failed

:missing_winget
echo [ERROR] WinGet is missing. Install or update App Installer from Microsoft Store:
echo https://apps.microsoft.com/detail/9NBLGGH4NNS1
goto :failed

:node_failed
echo [ERROR] WinGet could not install Node.js. Exit code: %RC%
goto :failed

:node_not_on_path
echo [ERROR] Node.js was installed but node.exe is not visible in PATH.
echo Restart Windows, then run this BAT again.
goto :failed

:npm_missing
echo [ERROR] npm was not found after Node.js installation.
goto :failed

:node_too_old
echo [ERROR] Node.js %NODE_VERSION% is too old for this project.
echo Install Node.js 22.12+ or a newer LTS release, then rerun this BAT.
goto :failed

:rust_failed
echo [ERROR] WinGet could not install Rustup. Exit code: %RC%
goto :failed

:rust_not_found
echo [ERROR] rustup.exe was not found after installation.
goto :failed

:rust_toolchain_failed
echo [ERROR] Rust MSVC toolchain installation failed. Exit code: %RC%
goto :failed

:rust_default_failed
echo [ERROR] Could not set the default Rust MSVC toolchain. Exit code: %RC%
goto :failed

:cargo_not_found
echo [ERROR] Cargo is missing. Close all terminals, reopen Windows, and rerun this BAT.
goto :failed

:rustc_not_found
echo [ERROR] rustc is missing after toolchain installation.
goto :failed

:vs_installer_missing
echo [ERROR] Visual Studio Installer setup.exe was not found.
goto :failed

:vs_modify_failed
echo [ERROR] Could not add the C++ workload to the existing Visual Studio. Exit code: %RC%
goto :failed

:vs_install_failed
echo [ERROR] Visual Studio Build Tools installation failed. Exit code: %RC%
echo Check the Visual Studio Installer and rerun this BAT.
goto :failed

:vswhere_missing
echo [ERROR] vswhere.exe is missing after Visual Studio installation.
goto :failed

:vs_component_missing
echo [ERROR] The C++ compiler workload was not detected after installation.
goto :failed

:npm_install_failed
echo [ERROR] npm install failed. Check internet access and the output above. Exit code: %RC%
goto :failed

:failed
>>"%LOG%" echo SETUP FAILED: %DATE% %TIME%
if defined RC >>"%LOG%" echo Last package exit code: %RC%
echo.
echo ================================================================
echo                 SETUP DID NOT COMPLETE
echo ================================================================
echo.
echo The window is intentionally kept open so you can read the error.
echo Send the error text and this log file to ChatGPT:
echo "%LOG%"
echo.
pause
exit /b 1
