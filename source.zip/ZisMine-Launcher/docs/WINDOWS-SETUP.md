# Установка среды сборки на Windows

## Важно

`SETUP-WINDOWS.bat` устанавливает инструменты РАЗРАБОТЧИКА, а не сам ZisMine Launcher для игроков. Игрокам эти инструменты не нужны. После выпуска игрок скачивает готовый EXE/MSI.

## Как запустить

1. Распакуй весь архив в отдельную папку, например `C:\ZisMine-Launcher`.
2. Убедись, что рядом с `SETUP-WINDOWS.bat` находятся папки `source`, `assets` и `.github`.
3. Дважды нажми `StepWindows.bat` или `SETUP-WINDOWS.bat`.
4. WinGet устанавливает Node.js LTS и Rustup. Для Visual Studio может открыться запрос UAC и окно установки C++ workload. Разреши установку.
5. Не закрывай окно до сообщения `SETUP COMPLETED SUCCESSFULLY`.
6. Запусти `BUILD-WINDOWS.bat` для NSIS EXE. Для MSI: `BUILD-WINDOWS.bat msi`. Для обоих форматов: `BUILD-WINDOWS.bat all`.

Установщику нужны Windows x64, интернет, App Installer с WinGet и несколько гигабайт свободного места для C++ Build Tools. В отличие от старого BAT, новая версия не повышает права для всего скрипта и не запускает себя повторно: отдельные системные установщики запрашивают UAC самостоятельно, а окно BAT остаётся открытым.

## Если что-то пошло не так

- Если `winget` не найден: установи или обнови App Installer из Microsoft Store: <https://apps.microsoft.com/detail/9NBLGGH4NNS1>.
- Если папка `source` не найдена: BAT запущен из неполностью распакованного архива или скопирован отдельно. Запускай его из корневой папки проекта.
- Если после установки `node`, `npm` или `cargo` не найдены: перезагрузи Windows и запусти `SETUP-WINDOWS.bat` повторно.
- Если установка npm-зависимостей не проходит: проверь доступ к registry.npmjs.org и прокси/антивирус.
- При ошибке отправь `SETUP-WINDOWS.log` и снимок окна. Дополнительно запусти `CHECK-WINDOWS.bat`.

## Что проверяет скрипт

Скрипт проверяет архитектуру Windows, наличие WinGet, Node.js и допустимую версию Node, npm, rustup, stable MSVC Rust toolchain, Cargo, rustc, наличие C++ workload через `vswhere`, а затем выполняет `npm install`. Каждая ошибка ведёт к сообщению с этапом и паузе; окно не должно просто исчезать.

WebView2 не устанавливается отдельным шагом: на Windows 10/11 он обычно уже есть, а Tauri Windows installer по умолчанию использует загрузку bootstrapper, когда runtime отсутствует. Для сборки MSI на некоторых системах может потребоваться включить необязательную возможность Windows `VBScript`.

## Проверка скриптов

`python tests/validate_windows_scripts.py` запускает статические проверки структуры BAT-файлов. Они не заменяют запуск на реальном Windows 10/11 компьютере.
