# Architecture — ZisMine Launcher 0.2.0

## Components

- React + TypeScript renders the Russian UI and sends typed commands through Tauri.
- Tauri 2 hosts a frameless window with custom controls and a restricted capability.
- Rust owns all file/network/game operations: Mojang manifest, Fabric Meta, Fabric Maven, Java Runtime, Microsoft authentication, mod files and process lifecycle.

## Pinned install profile

Only Minecraft `1.20.1` is accepted by frontend and backend. Mojang metadata is verified, Fabric Loader profile is fetched from `https://meta.fabricmc.net/v2/versions/loader/1.20.1`, validated for `inheritsFrom=1.20.1`, and merged with the vanilla launch metadata. Fabric API is selected from `maven.fabricmc.net` Maven metadata using the `+1.20.1` compatibility suffix. The downloaded JAR is stored in the instance `instances/1.20.1/mods/` folder and protected by the mod manager.

Minecraft 1.20.1 uses Java 17. The launcher obtains the platform-specific Java runtime through Mojang's official Runtime Manifest, checks manifest SHA-1 and per-file hashes, and runs `java -version` before launching. On Windows, the runtime root is `runtime/` beside the installed executable; the NSIS installer is current-user so the install folder is normally user-writable.

## Authentication

Microsoft login uses Device Code Flow → Xbox Live → XSTS → Minecraft Services. The backend checks Minecraft Java entitlement and profile. Refresh credentials are stored via the system keyring. A public OAuth Client ID must be configured; offline profiles are explicitly labelled as non-licensed.

## Launch / logs

The launcher substitutes Mojang argument placeholders, builds the classpath and starts Fabric's KnotClient main class. Windows starts `javaw.exe` (when available) with `CREATE_NO_WINDOW`; the launcher release uses the Windows GUI subsystem. Stdout and stderr are captured and persisted to `instances/1.20.1/logs/latest.log`; the optional in-app console is separate.

## Mods

`mods.rs` lists JAR files in `instances/1.20.1/mods/` and `instances/1.20.1/mods-disabled/`, reads the `fabric.mod.json` descriptor, validates file names before moves/deletes, and protects the managed Fabric API JAR. Minecraft dependency expressions are conservatively evaluated for common SemVer-style constraints; unsupported/missing expressions are marked unknown, not compatible.

## Security boundaries

- HTTPS and host allowlists for game/runtime artifacts.
- Path component checks for archive entries and user-selected mod file names.
- SHA-1 validation where official metadata/checksums provide it.
- Token storage through OS credential storage rather than local JSON.
- Existing worlds are not deleted by game version repair.

## Verification status

Source-level checks are not a substitute for a Windows build and game smoke test. This workspace does not have Cargo/Rust or a Windows runner. Confirm TypeScript production build, `cargo test`, NSIS bundle, actual Java 17 download, Fabric Loader/API install, Microsoft OAuth, and launch through the Minecraft main menu on Windows before public release.
