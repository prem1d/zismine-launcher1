# Audit — Fabric Edition / Redesign

Date: 2026-11-06
Version: 0.2.0

## Changed

1. The only accepted Minecraft version is now `1.20.1`; install, launch, settings and UI use this constant.
2. The install pipeline fetches official vanilla metadata and merges an official Fabric Loader profile. It selects a stable loader when available, validates `inheritsFrom`, and verifies the expected Fabric main class.
3. Fabric API is selected from Fabric Maven metadata by the exact `+1.20.1` suffix, SHA-1 is fetched, and the file is installed to `instances/1.20.1/mods/`. Old managed Fabric API JARs are cleaned up only after the new artifact is downloaded.
4. Java requirement is 17, read from the Mojang version JSON via `/javaVersion/majorVersion`, with a safe 17 fallback for the pinned client. Runtime is stored beside the Windows launcher executable under `runtime/`.
5. The mod page reads JAR descriptors and performs safe enable/disable/remove operations; Fabric API cannot be disabled or removed. Minecraft dependency status is conservative.
6. The UI now has a red/graphite palette, app/window branding, custom frameless title bar, and four pages.
7. Release build uses Windows GUI subsystem; game starts without a console window and logs to `instances/1.20.1/logs/latest.log`.
8. Existing Microsoft OAuth flow is retained; it checks Xbox/XSTS, Minecraft Services profile and Java entitlement, with refresh token held by keyring.

## Static checks

`tests/audit_minecraft.py` covers version pin, Fabric metadata, Java 17, OAuth path, borderless config, runtime placement, log file, mods and UI style. `tests/validate_windows_scripts.py` continues to validate setup/build scripts.

## Not verified here

This environment does not have `cargo`/`rustc` or a Windows runner. Therefore Rust compilation, NSIS packaging, live Fabric API compatibility selection, live runtime download, actual Microsoft account login and launching to the Minecraft menu have not been verified in this workspace. No installer is falsely marked as produced. A Windows build and smoke test remain required.
